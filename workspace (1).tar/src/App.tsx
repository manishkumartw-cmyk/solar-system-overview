import { lazy, Suspense, useCallback, useEffect, useRef, useState } from "react";
import Starfield from "./components/Starfield";
import SolarSystem from "./components/SolarSystem";
import MilkyWayScene from "./components/MilkyWayScene";
import LocalGroupScene from "./components/LocalGroupScene";
import SpaceTrackers from "./components/SpaceTrackers";
import DetailPanel from "./components/DetailPanel";
import ControlDock, { BASE_DAYS_PER_SEC, speedMultiplier } from "./components/ControlDock";
import { bodyById } from "./data/bodies";
import { COSMIC } from "./data/cosmic";

const SolarSystem3D = lazy(() => import("./components/SolarSystem3D"));

const LEVELS = [
  { name: "SOLAR SYSTEM", short: "System", desc: "1 STAR · 8 WORLDS" },
  { name: "MILKY WAY", short: "Galaxy", desc: "100–400 BN STARS" },
  { name: "LOCAL GROUP", short: "Local Group", desc: "~80 GALAXIES" },
] as const;

type Scope = 0 | 1 | 2;
interface Sel {
  scope: Scope;
  id: string;
}

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, []);
  return reduced;
}

function elapsedLabel(days: number): string {
  const y = Math.floor(days / 365.25);
  const d = Math.floor(days - y * 365.25);
  return `${String(y).padStart(2, "0")}y ${String(d).padStart(3, "0")}d`;
}

export default function App() {
  const reduced = usePrefersReducedMotion();
  const [playing, setPlaying] = useState(() => !reduced);
  const [speedValue, setSpeedValue] = useState(25); // 1×
  const [simDays, setSimDays] = useState(0);
  const [view, setView] = useState<"map" | "space">("map");

  /* ---- cosmic zoom state ---- */
  const [level, setLevel] = useState(0);
  const [solarZoom, setSolarZoom] = useState(1);
  const [sel, setSel] = useState<Sel | null>({ scope: 0, id: "earth" });
  const [warpKey, setWarpKey] = useState(0);

  const levelRef = useRef(0);
  const zoomRef = useRef(1);
  const shiftLockRef = useRef(0);
  levelRef.current = level;
  zoomRef.current = solarZoom;

  /* ---- simulation clock ---- */
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.1);
      last = now;
      setSimDays((d) => d + dt * BASE_DAYS_PER_SEC * speedMultiplier(speedValue));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, speedValue]);

  /* ---- zoom between cosmic scales ---- */
  const goLevel = useCallback((l: number) => {
    const cl = Math.max(0, Math.min(2, l));
    if (cl === levelRef.current) return;
    levelRef.current = cl;
    shiftLockRef.current = Date.now();
    setLevel(cl);
    setSel(null);
    setWarpKey((k) => k + 1);
  }, []);

  const zoomIn = useCallback(() => {
    const l = levelRef.current;
    if (l === 0) {
      const z = zoomRef.current;
      if (z >= 2.45) {
        if (Date.now() - shiftLockRef.current > 650) goLevel(1);
      } else {
        setSolarZoom(Math.min(2.6, z * 1.16));
      }
    } else if (l === 1) {
      if (Date.now() - shiftLockRef.current > 650) goLevel(2);
    }
  }, [goLevel]);

  const zoomOut = useCallback(() => {
    const l = levelRef.current;
    if (l === 0) {
      const z = zoomRef.current;
      if (z > 1.04) setSolarZoom(Math.max(1, z / 1.16));
    } else if (Date.now() - shiftLockRef.current > 650) {
      goLevel(l - 1);
    }
  }, [goLevel]);

  const canvasRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (e.deltaY < 0) zoomIn();
      else zoomOut();
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [zoomIn, zoomOut]);

  /* ---- keyboard shortcuts ---- */
  const togglePlay = useCallback(() => setPlaying((p) => !p), []);
  const reset = useCallback(() => setSimDays(0), []);
  const toggleView = useCallback(() => {
    setView((v) => (v === "map" ? "space" : "map"));
    if (levelRef.current !== 0) goLevel(0);
  }, [goLevel]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target !== document.body) return;
      if (e.code === "Space") {
        e.preventDefault();
        togglePlay();
      } else if (e.code === "KeyR") {
        reset();
      } else if (e.code === "KeyV") {
        toggleView();
      } else if (e.code === "ArrowRight") {
        setSpeedValue((v) => Math.min(100, v + 5));
      } else if (e.code === "ArrowLeft") {
        setSpeedValue((v) => Math.max(0, v - 5));
      } else if (e.key === "+" || e.key === "=") {
        zoomIn();
      } else if (e.key === "-" || e.key === "_") {
        zoomOut();
      } else if (e.key === "1") {
        goLevel(0);
      } else if (e.key === "2") {
        goLevel(1);
      } else if (e.key === "3") {
        goLevel(2);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePlay, reset, toggleView, zoomIn, zoomOut, goLevel]);

  const pick = (scope: Scope) => (id: string | null) =>
    setSel(id ? { scope, id } : null);

  const selectedBody = sel?.scope === 0 ? bodyById(sel.id) : null;
  const selectedCosmic = sel && sel.scope > 0 ? COSMIC[sel.id] ?? null : null;

  return (
    <div className="relative h-full w-full select-none overflow-hidden bg-[#04060d]">
      {/* deep-space base wash */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 90% at 50% 42%, #0b1226 0%, #070b18 46%, #04060d 100%)",
        }}
      />

      {/* nebulae */}
      <div
        className="nebula"
        style={{
          width: "58vw",
          height: "58vw",
          left: "-12vw",
          top: "16vh",
          background: "radial-gradient(circle, rgba(255,138,42,0.15), rgba(255,138,42,0) 66%)",
        }}
      />
      <div
        className="nebula"
        style={{
          width: "46vw",
          height: "46vw",
          right: "-10vw",
          top: "-12vh",
          background: "radial-gradient(circle, rgba(45,212,191,0.10), rgba(45,212,191,0) 64%)",
          animationDelay: "-14s",
        }}
      />
      <div
        className="nebula"
        style={{
          width: "62vw",
          height: "62vw",
          left: "22vw",
          bottom: "-26vh",
          background: "radial-gradient(circle, rgba(64,104,255,0.09), rgba(64,104,255,0) 65%)",
          animationDelay: "-28s",
        }}
      />

      {/* stars + comets */}
      <Starfield />
      <div className="absolute inset-0 z-[5] overflow-hidden" aria-hidden="true">
        <div className="comet comet-a" />
        <div className="comet comet-b" />
      </div>

      {/* scenes — three cosmic scales */}
      <div ref={canvasRef} className="absolute inset-0 z-10">
        <div className={`scene ${level === 0 ? "scene-on" : "scene-past"}`}>
          <div
            className="h-full w-full origin-center"
            style={{
              transform: `scale(${solarZoom})`,
              transition: "transform 0.28s cubic-bezier(0.22,1,0.36,1)",
            }}
          >
            {view === "map" ? (
              <SolarSystem
                simDays={simDays}
                selectedId={sel?.scope === 0 ? sel.id : null}
                onSelect={pick(0)}
              />
            ) : (
              <Suspense
                fallback={
                  <div className="absolute inset-0 grid place-items-center">
                    <p className="font-display animate-pulse text-[11px] font-bold tracking-[0.4em] text-amber-200/70">
                      CALIBRATING 3D OPTICS…
                    </p>
                  </div>
                }
              >
                <SolarSystem3D
                  simDays={simDays}
                  selectedId={sel?.scope === 0 ? sel.id : null}
                  onSelect={pick(0)}
                  reducedMotion={reduced}
                />
              </Suspense>
            )}
          </div>
        </div>

        <div className={`scene ${level === 1 ? "scene-on" : level < 1 ? "scene-future" : "scene-past"}`}>
          <MilkyWayScene selectedId={sel?.scope === 1 ? sel.id : null} onSelect={pick(1)} />
        </div>

        <div className={`scene ${level === 2 ? "scene-on" : level < 2 ? "scene-future" : "scene-past"}`}>
          <LocalGroupScene selectedId={sel?.scope === 2 ? sel.id : null} onSelect={pick(2)} />
        </div>
      </div>

      {/* warp flash on scale shift */}
      {warpKey > 0 && !reduced && <div key={warpKey} className="warp-flash" />}

      {/* vignette */}
      <div
        className="pointer-events-none absolute inset-0 z-20"
        style={{
          background:
            "radial-gradient(90% 90% at 50% 46%, rgba(0,0,0,0) 55%, rgba(2,4,10,0.55) 88%, rgba(2,4,10,0.8) 100%)",
        }}
      />

      {/* scale ladder */}
      <nav
        className="absolute left-6 top-1/2 z-40 hidden -translate-y-1/2 flex-col lg:flex"
        aria-label="Cosmic scale"
      >
        <p className="mb-2.5 text-[9px] font-medium tracking-[0.32em] text-slate-600">SCALE</p>
        <div className="relative flex flex-col gap-1">
          <span className="absolute bottom-3 left-[3.5px] top-3 w-px bg-white/10" aria-hidden="true" />
          {[2, 1, 0].map((i) => (
            <button key={LEVELS[i].name} onClick={() => goLevel(i)} className={`scale-node ${i === level ? "on" : ""}`}>
              <span className="dot" />
              <span className="lbl">{LEVELS[i].short}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* header */}
      <header className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between p-5 sm:p-7">
        <div>
          <p className="font-display text-[10px] font-bold tracking-[0.4em] text-amber-300/90 sm:text-[11px]">
            REALTIME ORRERY · SUN TO LOCAL GROUP
          </p>
          <h1 className="font-display mt-2 text-[28px] font-black leading-none tracking-[0.08em] text-[#f7f1e3] sm:text-4xl">
            ORBITARIUM
          </h1>
          <p className="mt-2 max-w-[280px] text-xs leading-relaxed text-slate-400 sm:text-[13px]">
            {reduced
              ? "Reduced motion detected — the system holds still until you press play."
              : "Scroll to zoom from the planets out to Andromeda. Click any body to inspect it."}
          </p>
        </div>
        <div className="pointer-events-auto flex flex-col items-end gap-2.5">
          <div
            className="flex items-center rounded-full border border-white/10 bg-black/40 p-1 backdrop-blur-sm"
            role="tablist"
            aria-label="View mode"
          >
            <button
              role="tab"
              aria-selected={view === "map"}
              className={`seg-btn ${view === "map" ? "seg-btn-on" : ""}`}
              onClick={() => {
                setView("map");
                if (levelRef.current !== 0) goLevel(0);
              }}
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none" />
                <ellipse cx="12" cy="12" rx="9.6" ry="4" />
                <ellipse cx="12" cy="12" rx="9.6" ry="4" transform="rotate(60 12 12)" opacity="0.45" />
              </svg>
              ORRERY MAP
            </button>
            <button
              role="tab"
              aria-selected={view === "space"}
              className={`seg-btn ${view === "space" ? "seg-btn-on" : ""}`}
              onClick={() => {
                setView("space");
                if (levelRef.current !== 0) goLevel(0);
              }}
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <circle cx="12" cy="12" r="8.6" />
                <ellipse cx="12" cy="12" rx="8.6" ry="3.4" />
                <path d="M12 3.4v17.2" opacity="0.35" />
              </svg>
              3D SPHERE
            </button>
          </div>
          <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-black/30 px-3.5 py-1.5 backdrop-blur-sm sm:flex">
            <span
              className={`h-1.5 w-1.5 rounded-full ${playing ? "pulse-dot bg-amber-300" : "bg-slate-500"}`}
            />
            <span className="font-display text-[10px] font-bold tracking-[0.28em] text-slate-300">
              {playing ? "SIMULATION RUNNING" : "PAUSED"}
            </span>
          </div>
        </div>
      </header>

      {/* zoom stepper */}
      <div className="absolute bottom-6 right-6 z-40 flex flex-col items-end gap-2">
        <div className="flex items-baseline gap-2.5 rounded-full border border-white/10 bg-black/40 px-4 py-1.5 backdrop-blur-sm">
          <span className="font-display text-[10px] font-bold tracking-[0.28em] text-amber-200/90">
            {LEVELS[level].name}
          </span>
          <span className="font-display text-[10px] tracking-[0.14em] text-slate-500">
            {level === 0 ? `${solarZoom.toFixed(1)}×` : LEVELS[level].desc}
          </span>
        </div>
        <div className="flex gap-1.5">
          <button className="zoom-btn" onClick={zoomOut} aria-label="Zoom out toward larger scales" title="Zoom out ( − )">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
              <path d="M2.5 7h9" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
            </svg>
          </button>
          <button className="zoom-btn" onClick={zoomIn} aria-label="Zoom in toward smaller scales" title="Zoom in ( + )">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
              <path d="M2.5 7h9M7 2.5v9" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

      {/* ISS + Hubble live tracker (solar-system scale only) */}
      <SpaceTrackers visible={level === 0} />

      {/* hints */}
      <p className="pointer-events-none absolute bottom-5 left-1/2 z-30 hidden -translate-x-1/2 text-[11px] tracking-wide text-slate-600 lg:block">
        Click a body&ensp;·&ensp;Scroll = cosmic zoom&ensp;·&ensp;1/2/3 scales&ensp;·&ensp;Space play/pause&ensp;·&ensp;← → time warp&ensp;·&ensp;V map ⇄ 3D
      </p>

      <DetailPanel body={selectedBody} cosmic={selectedCosmic} simDays={simDays} onClose={() => setSel(null)} />

      <ControlDock
        playing={playing}
        onTogglePlay={togglePlay}
        onReset={reset}
        speedValue={speedValue}
        onSpeedChange={setSpeedValue}
        elapsedLabel={elapsedLabel(simDays)}
        reduced={reduced}
      />
    </div>
  );
}
