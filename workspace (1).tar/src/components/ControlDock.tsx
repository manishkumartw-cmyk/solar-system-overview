import type { CSSProperties } from "react";

interface Props {
  playing: boolean;
  onTogglePlay: () => void;
  onReset: () => void;
  speedValue: number; // 0..100
  onSpeedChange: (v: number) => void;
  elapsedLabel: string;
  reduced: boolean;
}

export const BASE_DAYS_PER_SEC = 12;

/** exponential time warp: 0→¼×, 25→1×, 50→4×, 75→16×, 100→64× */
export function speedMultiplier(v: number): number {
  return Math.pow(4, v / 25) / 4;
}

const PRESETS: Array<{ label: string; value: number }> = [
  { label: "¼×", value: 0 },
  { label: "1×", value: 25 },
  { label: "4×", value: 50 },
  { label: "16×", value: 75 },
  { label: "64×", value: 100 },
];

function PlayIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M8 5.14v13.72c0 .8.87 1.3 1.56.88l10.54-6.86a1.04 1.04 0 0 0 0-1.76L9.56 4.26A1.04 1.04 0 0 0 8 5.14Z" />
    </svg>
  );
}
function PauseIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <rect x="6" y="4.5" width="4" height="15" rx="1.2" />
      <rect x="14" y="4.5" width="4" height="15" rx="1.2" />
    </svg>
  );
}
function ResetIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 12a9 9 0 1 0 2.6-6.4" />
      <path d="M3 4v5h5" />
    </svg>
  );
}

export default function ControlDock({
  playing,
  onTogglePlay,
  onReset,
  speedValue,
  onSpeedChange,
  elapsedLabel,
  reduced,
}: Props) {
  const mult = speedMultiplier(speedValue);
  const dps = BASE_DAYS_PER_SEC * mult;
  const multLabel = mult < 1 ? mult.toFixed(2).replace(/0$/, "") : `${Math.round(mult)}`;
  const dpsLabel = dps >= 100 ? Math.round(dps).toString() : dps >= 10 ? dps.toFixed(0) : dps.toFixed(1);

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-4 z-40 flex justify-center px-3 sm:bottom-6">
      <div className="pointer-events-auto flex w-[min(94vw,700px)] flex-wrap items-center justify-center gap-x-5 gap-y-3 rounded-xl border border-white/10 bg-[#0a1120]/85 px-4 py-3 shadow-[0_24px_70px_rgba(0,0,0,0.6)] backdrop-blur-md sm:px-6">
        {/* transport */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onTogglePlay}
            aria-label={playing ? "Pause simulation" : "Play simulation"}
            className="grid h-11 w-11 place-items-center rounded-full bg-amber-400 text-[#221503] shadow-[0_0_26px_rgba(251,191,36,0.4)] transition-all duration-200 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] hover:bg-amber-300 hover:shadow-[0_0_36px_rgba(251,191,36,0.55)] active:scale-90"
          >
            <span key={playing ? "pause" : "play"} className="grid place-items-center">
              {playing ? <PauseIcon /> : <PlayIcon />}
            </span>
          </button>
          <button
            onClick={onReset}
            aria-label="Reset simulation time"
            className="grid h-9 w-9 place-items-center rounded-full border border-white/15 text-slate-400 transition-all duration-200 hover:border-amber-300/60 hover:text-amber-300 active:scale-90"
          >
            <ResetIcon />
          </button>
        </div>

        <div className="hidden h-9 w-px bg-white/10 sm:block" />

        {/* time warp */}
        <div className="min-w-[180px] flex-1 sm:max-w-[240px]">
          <div className="flex items-baseline justify-between">
            <label htmlFor="warp" className="text-[10px] font-medium uppercase tracking-[0.24em] text-slate-500">
              Time warp
            </label>
            <span className="font-display text-[12px] font-bold text-amber-300">
              {multLabel}×
              <span className="ml-1.5 font-medium text-slate-500">{dpsLabel} d/s</span>
            </span>
          </div>
          <input
            id="warp"
            type="range"
            min={0}
            max={100}
            step={1}
            value={speedValue}
            onChange={(e) => onSpeedChange(Number(e.target.value))}
            className="speed-range mt-2"
            style={{ "--fill": `${speedValue}%` } as CSSProperties}
            aria-label="Simulation speed"
          />
          <div className="mt-1.5 flex justify-between">
            {PRESETS.map((p) => (
              <button
                key={p.value}
                onClick={() => onSpeedChange(p.value)}
                className={`font-display rounded px-1 text-[10px] font-semibold transition-colors duration-200 ${
                  speedValue === p.value ? "text-amber-300" : "text-slate-600 hover:text-slate-300"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="hidden h-9 w-px bg-white/10 sm:block" />

        {/* mission clock */}
        <div className="text-center sm:text-left">
          <p className="text-[10px] font-medium uppercase tracking-[0.24em] text-slate-500">Mission clock</p>
          <p className="font-display mt-0.5 text-[15px] font-bold tracking-wider text-[#f2ead9]">
            T+{elapsedLabel}
          </p>
        </div>

        {reduced && (
          <p className="w-full text-center text-[10px] tracking-wide text-slate-500">
            Reduced motion detected — simulation starts paused.
          </p>
        )}
      </div>
    </div>
  );
}
