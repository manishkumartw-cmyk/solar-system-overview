import { SUN, angleAt, type Body } from "../data/bodies";
import type { CosmicBody } from "../data/cosmic";

interface Props {
  body: Body | null;
  cosmic?: CosmicBody | null;
  simDays: number;
  onClose: () => void;
}

const MAX_DIAMETER = SUN.diameterKm;
const MIN_DIAMETER = 4879;
const MIN_AU = 0.387;
const MAX_AU = 30.069;

function sizePct(d: number): number {
  const p = (Math.log(d / MIN_DIAMETER) / Math.log(MAX_DIAMETER / MIN_DIAMETER)) * 100;
  return Math.min(100, Math.max(5, p));
}
function distPct(au: number): number {
  if (au <= 0) return 0;
  return Math.min(100, Math.max(4, (Math.log(au / MIN_AU) / Math.log(MAX_AU / MIN_AU)) * 100));
}

function formatLongitude(body: Body, simDays: number): string {
  if (body.id === "sun") {
    const rot = ((simDays / 25.38) * 360) % 360;
    return `${rot.toFixed(1)}° spin`;
  }
  const deg = (((angleAt(body, simDays) * 180) / Math.PI) % 360 + 360) % 360;
  return `${deg.toFixed(1)}°`;
}

export default function DetailPanel({ body, cosmic = null, simDays, onClose }: Props) {
  const visible = body !== null || cosmic !== null;

  return (
    <aside
      className="absolute inset-x-3 bottom-[7.2rem] top-[6.2rem] z-40 sm:inset-x-auto sm:bottom-auto sm:right-5 sm:top-1/2 sm:w-[340px] sm:-translate-y-1/2 lg:right-8"
      aria-hidden={!visible}
    >
      <div
        className={`panel-scroll h-full overflow-y-auto rounded-xl border border-white/10 bg-[#0a101f]/90 shadow-[0_30px_80px_rgba(0,0,0,0.55)] backdrop-blur-md transition-all duration-500 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] sm:h-auto sm:max-h-[calc(100vh-9rem)] ${
          visible ? "translate-x-0 opacity-100" : "pointer-events-none translate-x-10 opacity-0"
        }`}
      >
        {body && (
          <div className="p-5">
            {/* header */}
            <div className="flex items-start justify-between gap-3">
              <p
                className="font-display text-[10px] font-bold tracking-[0.32em]"
                style={{ color: body.color }}
              >
                {body.id === "sun" ? "STAR · BODY 00" : `${body.type.toUpperCase()} · BODY ${body.index}`}
              </p>
              <button
                onClick={onClose}
                aria-label="Close details"
                className="-mr-1 -mt-1 grid h-7 w-7 place-items-center rounded-full text-slate-500 transition-colors duration-200 hover:bg-white/5 hover:text-white"
              >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                  <path d="M1 1l10 10M11 1L1 11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                </svg>
              </button>
            </div>

            {/* name + swatch */}
            <div className="mt-3 flex items-center gap-4">
              <div
                className="h-12 w-12 shrink-0 rounded-full"
                style={{
                  background:
                    body.id === "sun"
                      ? "radial-gradient(circle at 40% 36%, #fffbe8, #ffe08a 40%, #ffb43a 72%, #ff7a1f)"
                      : `radial-gradient(circle at 33% 30%, ${body.light}, ${body.color} 55%, ${body.dark})`,
                  boxShadow: `0 0 26px ${body.color}66, 0 0 60px ${body.color}2e`,
                }}
              />
              <h2 className="font-display text-[26px] font-extrabold uppercase leading-none tracking-[0.06em] text-[#f7f1e3]">
                {body.name}
              </h2>
            </div>

            {/* stats */}
            <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3.5">
              {body.stats.map((s) => (
                <div key={s.label}>
                  <dt className="text-[10px] font-medium uppercase tracking-[0.22em] text-slate-500">
                    {s.label}
                  </dt>
                  <dd className="font-display mt-1 text-[12.5px] font-semibold text-[#f0ead9]">
                    {s.value}
                  </dd>
                </div>
              ))}
            </dl>

            {/* comparison meters */}
            <div className="mt-5 space-y-3.5">
              <div>
                <div className="flex items-baseline justify-between">
                  <span className="text-[10px] uppercase tracking-[0.22em] text-slate-500">
                    Diameter · log scale
                  </span>
                  <span className="font-display text-[11px] text-slate-300">
                    {body.diameterKm.toLocaleString("en-US")} km
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full transition-all duration-700 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)]"
                    style={{
                      width: `${sizePct(body.diameterKm)}%`,
                      background: body.color,
                      boxShadow: `0 0 10px ${body.color}aa`,
                    }}
                  />
                </div>
              </div>
              <div>
                <div className="flex items-baseline justify-between">
                  <span className="text-[10px] uppercase tracking-[0.22em] text-slate-500">
                    Distance from Sun · log AU
                  </span>
                  <span className="font-display text-[11px] text-slate-300">
                    {body.au > 0 ? `${body.au.toFixed(2)} AU` : "center"}
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full transition-all duration-700 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)]"
                    style={{
                      width: `${distPct(body.au)}%`,
                      background: body.au > 0 ? body.color : "#ffb43a",
                      boxShadow: `0 0 10px ${body.color}aa`,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* fact */}
            <p
              className="mt-5 border-l-2 pl-3.5 text-[13px] leading-relaxed text-slate-400"
              style={{ borderColor: body.color }}
            >
              {body.blurb}
            </p>

            {/* live telemetry */}
            <div className="mt-5 flex items-center justify-between border-t border-white/[0.08] pt-3.5">
              <span className="text-[10px] uppercase tracking-[0.22em] text-slate-600">
                {body.id === "sun" ? "Equatorial" : "Heliocentric"} longitude
              </span>
              <span className="font-display text-[12px] font-semibold text-amber-300">
                {formatLongitude(body, simDays)}
              </span>
            </div>
          </div>
        )}

        {!body && cosmic && (
          <div className="p-5">
            <div className="flex items-start justify-between gap-3">
              <p
                className="font-display text-[10px] font-bold tracking-[0.32em]"
                style={{ color: cosmic.color }}
              >
                {cosmic.type.toUpperCase()} · {cosmic.index}
              </p>
              <button
                onClick={onClose}
                aria-label="Close details"
                className="-mr-1 -mt-1 grid h-7 w-7 place-items-center rounded-full text-slate-500 transition-colors duration-200 hover:bg-white/5 hover:text-white"
              >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                  <path d="M1 1l10 10M11 1L1 11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                </svg>
              </button>
            </div>

            <div className="mt-3 flex items-center gap-4">
              <div
                className="h-12 w-12 shrink-0 rounded-full"
                style={{
                  background: `radial-gradient(circle at 33% 30%, ${cosmic.light}, ${cosmic.color} 55%, ${cosmic.dark})`,
                  boxShadow: `0 0 26px ${cosmic.color}66, 0 0 60px ${cosmic.color}2e`,
                }}
              />
              <h2 className="font-display text-[24px] font-extrabold uppercase leading-tight tracking-[0.05em] text-[#f7f1e3]">
                {cosmic.name}
              </h2>
            </div>

            <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3.5">
              {cosmic.stats.map((s) => (
                <div key={s.label}>
                  <dt className="text-[10px] font-medium uppercase tracking-[0.22em] text-slate-500">
                    {s.label}
                  </dt>
                  <dd className="font-display mt-1 text-[12.5px] font-semibold text-[#f0ead9]">
                    {s.value}
                  </dd>
                </div>
              ))}
            </dl>

            <p
              className="mt-5 border-l-2 pl-3.5 text-[13px] leading-relaxed text-slate-400"
              style={{ borderColor: cosmic.color }}
            >
              {cosmic.blurb}
            </p>

            <div className="mt-5 flex items-center justify-between border-t border-white/[0.08] pt-3.5">
              <span className="text-[10px] uppercase tracking-[0.22em] text-slate-600">
                Deep-field archive
              </span>
              <span className="font-display text-[12px] font-semibold text-amber-300">
                {cosmic.index}
              </span>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
