import type { CSSProperties } from "react";
import { spiralPath, armStars, type ArmStar } from "../data/cosmic";

interface GalCfg {
  id: string;
  cx: number;
  cy: number;
  r: number;
  tilt: number;
  phase: number;
  turns: number;
  seed: number;
  starCount: number;
  spinDur: string;
  reverse?: boolean;
  label: string;
  sub: string;
  armColor: string;
  thinColor: string;
  coreLight: string;
}

const GALAXIES: GalCfg[] = [
  {
    id: "milkyway",
    cx: 280,
    cy: 600,
    r: 150,
    tilt: -16,
    phase: 0.8,
    turns: 1.9,
    seed: 101,
    starCount: 130,
    spinDur: "150s",
    label: "MILKY WAY",
    sub: "OUR GALAXY · ~100,000 LY ACROSS",
    armColor: "#8fa8e0",
    thinColor: "#d7e2ff",
    coreLight: "#ffedbe",
  },
  {
    id: "andromeda",
    cx: 720,
    cy: 300,
    r: 190,
    tilt: 22,
    phase: 2.2,
    turns: 1.8,
    seed: 202,
    starCount: 175,
    spinDur: "200s",
    reverse: true,
    label: "ANDROMEDA · M31",
    sub: "2.54M LY AWAY · APPROACHING AT 110 KM/S",
    armColor: "#b9a5de",
    thinColor: "#ead9ff",
    coreLight: "#ffe0ac",
  },
  {
    id: "triangulum",
    cx: 868,
    cy: 585,
    r: 62,
    tilt: 8,
    phase: 1.2,
    turns: 2.2,
    seed: 303,
    starCount: 46,
    spinDur: "110s",
    label: "TRIANGULUM · M33",
    sub: "2.73M LY · THIRD LARGEST",
    armColor: "#8fb8f0",
    thinColor: "#d9ebff",
    coreLight: "#eef4ff",
  },
];

interface GalArt {
  armA: string;
  armB: string;
  dustA: string;
  dustB: string;
  stars: ArmStar[];
}

function build(cfg: GalCfg): GalArt {
  return {
    armA: spiralPath(cfg.r, cfg.turns, cfg.phase, 0, 0, 120),
    armB: spiralPath(cfg.r, cfg.turns, cfg.phase + Math.PI, 0, 0, 120),
    dustA: spiralPath(cfg.r * 0.78, cfg.turns, cfg.phase + 0.32, 0, 0, 110),
    dustB: spiralPath(cfg.r * 0.78, cfg.turns, cfg.phase + Math.PI + 0.32, 0, 0, 110),
    stars: armStars(cfg.seed, 2, cfg.r * 1.05, cfg.turns, cfg.phase, cfg.starCount, cfg.r * 0.075, 0, 0),
  };
}

const ART: Record<string, GalArt> = Object.fromEntries(GALAXIES.map((g) => [g.id, build(g)]));

interface Props {
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}

export default function LocalGroupScene({ selectedId, onSelect }: Props) {
  return (
    <svg
      className="h-full w-full"
      viewBox="0 0 1000 1000"
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="The Local Group of galaxies — Milky Way, Andromeda and neighbours"
      onClick={() => onSelect(null)}
    >
      <defs>
        <radialGradient id="lg-halo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(160,180,235,0.16)" />
          <stop offset="100%" stopColor="rgba(160,180,235,0)" />
        </radialGradient>
        <radialGradient id="lg-core" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(255,244,214,0.95)" />
          <stop offset="55%" stopColor="rgba(255,220,150,0.45)" />
          <stop offset="100%" stopColor="rgba(255,210,140,0)" />
        </radialGradient>
        <radialGradient id="lg-cloud" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(190,235,225,0.75)" />
          <stop offset="100%" stopColor="rgba(160,215,205,0)" />
        </radialGradient>
        <filter id="lg-blur" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="7" />
        </filter>
        <filter id="lg-blur-sm" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2.6" />
        </filter>
        <marker id="lg-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" fill="#e8c48f" />
        </marker>
      </defs>

      {/* collision course connector */}
      <g>
        <path
          d="M 419 505 Q 480 445 548 417"
          fill="none"
          stroke="#e8c48f"
          strokeWidth={1.4}
          strokeDasharray="5 6"
          opacity={0.75}
          markerEnd="url(#lg-arrow)"
          markerStart="url(#lg-arrow)"
        />
        <text x={487} y={512} textAnchor="middle" fontSize={13} letterSpacing={2.4} fill="#f2dfb8" style={{ fontFamily: "var(--font-display)" }}>
          2.54 MILLION LIGHT-YEARS
        </text>
        <text x={487} y={530} textAnchor="middle" fontSize={9.5} letterSpacing={1.5} fill="#8b93a8">
          CLOSING AT 110 KM/S · MERGER IN ~4.5 BILLION YEARS → “MILKOMEDA”
        </text>
      </g>

      {/* galaxies */}
      {GALAXIES.map((cfg) => {
        const art = ART[cfg.id];
        const selected = selectedId === cfg.id;
        return (
          <g key={cfg.id}>
            <g transform={`translate(${cfg.cx} ${cfg.cy}) rotate(${cfg.tilt})`}>
              <g
                className={cfg.reverse ? "spin-fill-rev" : "spin-fill"}
                style={{ "--spin": cfg.spinDur } as CSSProperties}
              >
                <circle r={cfg.r * 1.18} fill="url(#lg-halo)" />
                {[art.armA, art.armB].map((d, i) => (
                  <g key={i} fill="none">
                    <path d={d} stroke={cfg.armColor} strokeWidth={cfg.r * 0.27} strokeOpacity={0.1} filter="url(#lg-blur)" />
                    <path d={d} stroke={cfg.armColor} strokeWidth={cfg.r * 0.1} strokeOpacity={0.18} filter="url(#lg-blur-sm)" />
                    <path d={d} stroke={cfg.thinColor} strokeWidth={1.6} strokeOpacity={0.55} strokeDasharray="1.2 6" strokeLinecap="round" />
                  </g>
                ))}
                {[art.dustA, art.dustB].map((d, i) => (
                  <path key={`d${i}`} d={d} fill="none" stroke="#04070f" strokeWidth={cfg.r * 0.05} strokeOpacity={0.5} filter="url(#lg-blur-sm)" />
                ))}
                {art.stars.map((s, i) => (
                  <circle key={i} cx={s.x.toFixed(1)} cy={s.y.toFixed(1)} r={s.r} fill={s.warm ? "#ffe3b3" : "#cfe0ff"} opacity={s.o} />
                ))}
                <ellipse rx={cfg.r * 0.55} ry={cfg.r * 0.34} fill="url(#lg-core)" filter="url(#lg-blur-sm)" />
                <ellipse rx={cfg.r * 0.2} ry={cfg.r * 0.12} fill={cfg.coreLight} filter="url(#lg-blur-sm)" />
              </g>
            </g>
            <g
              className="cosmic-hit"
              onClick={(e) => {
                e.stopPropagation();
                onSelect(cfg.id);
              }}
              role="button"
              tabIndex={0}
              aria-label={`${cfg.label} — view details`}
              onKeyDown={(e) => e.key === "Enter" && onSelect(cfg.id)}
            >
              <circle cx={cfg.cx} cy={cfg.cy} r={cfg.r * 0.98} fill="transparent" />
              <circle
                className={`hit-ring ${selected ? "is-on" : ""}`}
                cx={cfg.cx}
                cy={cfg.cy}
                r={cfg.r * 1.04}
                fill="none"
                stroke={cfg.coreLight}
                strokeWidth={1.2}
                strokeDasharray="3 7"
              />
              <text
                x={cfg.cx}
                y={cfg.cy + cfg.r + 36}
                textAnchor="middle"
                fontSize={13.5}
                letterSpacing={2.4}
                fill={selected ? cfg.coreLight : "#dfe6f5"}
                style={{ fontFamily: "var(--font-display)" }}
              >
                {cfg.label}
              </text>
              <text x={cfg.cx} y={cfg.cy + cfg.r + 54} textAnchor="middle" fontSize={9.5} letterSpacing={1.4} fill="#7d8ba6">
                {cfg.sub}
              </text>
            </g>
          </g>
        );
      })}

      {/* Andromeda's small satellites */}
      <ellipse cx={628} cy={172} rx={16} ry={9} fill="url(#lg-core)" opacity={0.5} filter="url(#lg-blur-sm)" transform="rotate(18 628 172)" />
      <text x={628} y={152} textAnchor="middle" fontSize={9} letterSpacing={1.6} fill="#68768f">M32</text>
      <ellipse cx={838} cy={420} rx={20} ry={10} fill="url(#lg-core)" opacity={0.45} filter="url(#lg-blur-sm)" transform="rotate(-24 838 420)" />
      <text x={866} y={408} fontSize={9} letterSpacing={1.6} fill="#68768f">M110</text>

      {/* Magellanic Clouds */}
      <g
        className="cosmic-hit"
        onClick={(e) => {
          e.stopPropagation();
          onSelect("lmc");
        }}
        role="button"
        tabIndex={0}
        aria-label="Large Magellanic Cloud"
        onKeyDown={(e) => e.key === "Enter" && onSelect("lmc")}
      >
        <ellipse cx={400} cy={790} rx={42} ry={28} fill="transparent" />
        <ellipse className={`hit-ring ${selectedId === "lmc" ? "is-on" : ""}`} cx={400} cy={790} rx={44} ry={30} fill="none" stroke="#a8e0d8" strokeWidth={1.1} strokeDasharray="3 6" />
        <ellipse cx={400} cy={790} rx={28} ry={17} fill="url(#lg-cloud)" filter="url(#lg-blur-sm)" transform="rotate(20 400 790)" />
        <ellipse cx={394} cy={787} rx={10} ry={6} fill="#d9fff4" opacity={0.8} filter="url(#lg-blur-sm)" />
        <text x={400} y={836} textAnchor="middle" fontSize={11} letterSpacing={2} fill="#c9efe7" style={{ fontFamily: "var(--font-display)" }}>
          LARGE MAGELLANIC CLOUD
        </text>
        <text x={400} y={852} textAnchor="middle" fontSize={9} letterSpacing={1.3} fill="#7d8ba6">
          163,000 LY · SATELLITE OF THE MILKY WAY
        </text>
      </g>
      <g
        className="cosmic-hit"
        onClick={(e) => {
          e.stopPropagation();
          onSelect("smc");
        }}
        role="button"
        tabIndex={0}
        aria-label="Small Magellanic Cloud"
        onKeyDown={(e) => e.key === "Enter" && onSelect("smc")}
      >
        <ellipse cx={486} cy={868} rx={28} ry={20} fill="transparent" />
        <ellipse className={`hit-ring ${selectedId === "smc" ? "is-on" : ""}`} cx={486} cy={868} rx={30} ry={21} fill="none" stroke="#9ad0e8" strokeWidth={1.1} strokeDasharray="3 6" />
        <ellipse cx={486} cy={868} rx={15} ry={9} fill="url(#lg-cloud)" filter="url(#lg-blur-sm)" transform="rotate(-14 486 868)" />
        <text x={486} y={903} textAnchor="middle" fontSize={10} letterSpacing={1.8} fill="#bfe4f2" style={{ fontFamily: "var(--font-display)" }}>
          SMALL MAGELLANIC CLOUD
        </text>
      </g>
      <path d="M 372 776 Q 300 720 292 660" fill="none" stroke="#8fd8c8" strokeWidth={1} strokeDasharray="2 5" opacity={0.4} />

      {/* captions */}
      <text x={940} y={78} textAnchor="end" fontSize={10} letterSpacing={2.4} fill="#68768f">
        DWARF GALAXIES PARTIALLY SHOWN · ~80 MEMBERS TOTAL
      </text>
      <text x={60} y={905} fontSize={11.5} letterSpacing={2.6} fill="#8fa0bd" style={{ fontFamily: "var(--font-display)" }}>
        THE LOCAL GROUP · ~10 MILLION LIGHT-YEARS ACROSS
      </text>
      <text x={60} y={926} fontSize={9.5} letterSpacing={1.6} fill="#68768f">
        POSITIONS SCHEMATIC — NOT TO SCALE · MILKY WAY AND ANDROMEDA DOMINATE
      </text>
      <g stroke="#68768f" strokeWidth={1}>
        <line x1={790} y1={902} x2={930} y2={902} />
        <line x1={790} y1={897} x2={790} y2={907} />
        <line x1={930} y1={897} x2={930} y2={907} />
      </g>
      <text x={860} y={924} textAnchor="middle" fontSize={9.5} letterSpacing={2} fill="#68768f">
        1 MILLION LIGHT-YEARS
      </text>
    </svg>
  );
}
