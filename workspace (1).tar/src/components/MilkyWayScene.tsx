import type { CSSProperties } from "react";
import { spiralPath, spiralPoint, armStars } from "../data/cosmic";

const CX = 500;
const CY = 470;
const R = 335;
const TURNS = 2.02;
const PHASE = 2.3;

const ARM_A = spiralPath(R, TURNS, PHASE, CX, CY);
const ARM_B = spiralPath(R, TURNS, PHASE + Math.PI, CX, CY);
const DUST_A = spiralPath(R * 0.8, TURNS, PHASE + 0.3, CX, CY);
const DUST_B = spiralPath(R * 0.8, TURNS, PHASE + Math.PI + 0.3, CX, CY);
const STARS = armStars(7, 2, R * 1.03, TURNS, PHASE, 270, 24, CX, CY);
const SUNP = spiralPoint(0.64, R, TURNS, PHASE, CX, CY);
const HUB = { x: SUNP.x + 52, y: SUNP.y + 30 };

interface Props {
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}

const spinOrigin = {
  transformBox: "view-box",
  transformOrigin: `${CX}px ${CY}px`,
} as CSSProperties;

export default function MilkyWayScene({ selectedId, onSelect }: Props) {
  return (
    <svg
      className="h-full w-full"
      viewBox="0 0 1000 1000"
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="Top-down view of the Milky Way galaxy"
      onClick={() => onSelect(null)}
    >
      <defs>
        <radialGradient id="mw-halo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(120,150,230,0.20)" />
          <stop offset="55%" stopColor="rgba(90,120,200,0.07)" />
          <stop offset="100%" stopColor="rgba(90,120,200,0)" />
        </radialGradient>
        <radialGradient id="mw-core" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fffbe9" />
          <stop offset="30%" stopColor="#ffe7ae" />
          <stop offset="65%" stopColor="rgba(255,205,120,0.5)" />
          <stop offset="100%" stopColor="rgba(255,190,100,0)" />
        </radialGradient>
        <filter id="mw-blur-lg" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="13" />
        </filter>
        <filter id="mw-blur-sm" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="5" />
        </filter>
      </defs>

      {/* rotating galactic disc */}
      <g className="spin-vb" style={{ ...spinOrigin, "--spin": "260s" } as CSSProperties}>
        <circle cx={CX} cy={CY} r={398} fill="url(#mw-halo)" />
        {[ARM_A, ARM_B].map((d, i) => (
          <g key={i} fill="none">
            <path d={d} stroke="#7f9fe8" strokeWidth={92} strokeOpacity={0.09} filter="url(#mw-blur-lg)" />
            <path d={d} stroke="#a9c2ff" strokeWidth={32} strokeOpacity={0.15} filter="url(#mw-blur-sm)" />
            <path
              d={d}
              stroke="#dbe7ff"
              strokeWidth={2.2}
              strokeOpacity={0.5}
              strokeDasharray="1.5 8.5"
              strokeLinecap="round"
            />
          </g>
        ))}
        {[DUST_A, DUST_B].map((d, i) => (
          <path key={`d${i}`} d={d} fill="none" stroke="#04070f" strokeWidth={13} strokeOpacity={0.5} filter="url(#mw-blur-sm)" />
        ))}
        {STARS.map((s, i) => (
          <circle key={i} cx={s.x.toFixed(1)} cy={s.y.toFixed(1)} r={s.r} fill={s.warm ? "#ffe3b3" : "#cfe0ff"} opacity={s.o} />
        ))}
        {/* central bar + bulge */}
        <g transform={`rotate(-24 ${CX} ${CY})`}>
          <ellipse cx={CX} cy={CY} rx={185} ry={36} fill="#ffdf9e" opacity={0.16} filter="url(#mw-blur-lg)" />
          <ellipse cx={CX} cy={CY} rx={148} ry={90} fill="url(#mw-core)" filter="url(#mw-blur-sm)" />
          <ellipse cx={CX} cy={CY} rx={52} ry={32} fill="#fff3d0" opacity={0.95} filter="url(#mw-blur-sm)" />
          <ellipse cx={CX} cy={CY} rx={20} ry={12} fill="#fffdf2" />
        </g>
      </g>

      {/* galactic core — clickable */}
      <g
        className="cosmic-hit"
        onClick={(e) => {
          e.stopPropagation();
          onSelect("milkyway");
        }}
        role="button"
        tabIndex={0}
        aria-label="Milky Way galactic core — Sagittarius A*"
        onKeyDown={(e) => e.key === "Enter" && onSelect("milkyway")}
      >
        <circle cx={CX} cy={CY} r={70} fill="transparent" />
        <g transform={`rotate(-24 ${CX} ${CY})`}>
          <ellipse
            className={`hit-ring ${selectedId === "milkyway" ? "is-on" : ""}`}
            cx={CX}
            cy={CY}
            rx={92}
            ry={62}
            fill="none"
            stroke="#ffd98a"
            strokeWidth={1.2}
            strokeDasharray="3 7"
          />
        </g>
        <line x1={CX + 62} y1={CY - 48} x2={CX + 118} y2={CY - 84} stroke="#8b93a8" strokeWidth={1} opacity={0.6} />
        <text x={CX + 124} y={CY - 88} fontSize={12} letterSpacing={2.4} fill="#c9d2e4" style={{ fontFamily: "var(--font-display)" }}>
          SAGITTARIUS A*
        </text>
        <text x={CX + 124} y={CY - 72} fontSize={9.5} letterSpacing={1.6} fill="#68768f">
          SUPERMASSIVE BLACK HOLE · 4.15 M M☉
        </text>
      </g>

      {/* Solar System marker */}
      <g
        className="cosmic-hit"
        transform={`translate(${SUNP.x.toFixed(1)} ${SUNP.y.toFixed(1)})`}
        onClick={(e) => {
          e.stopPropagation();
          onSelect("sun-far");
        }}
        role="button"
        tabIndex={0}
        aria-label="Position of the Solar System in the galaxy"
        onKeyDown={(e) => e.key === "Enter" && onSelect("sun-far")}
      >
        <circle r={30} fill="transparent" />
        <circle className={`hit-ring ${selectedId === "sun-far" ? "is-on" : ""}`} r={26} fill="none" stroke="#ffd98a" strokeWidth={1.2} strokeDasharray="3 6" />
        <circle className="marker-ping" r={12} fill="none" stroke="#ffd98a" strokeWidth={1.4} />
        <circle r={9} fill="rgba(255,214,138,0.28)" />
        <circle r={4.2} fill="#ffe08a" />
        {[0, 90, 180, 270].map((deg) => (
          <line
            key={deg}
            x1={10 * Math.cos((deg * Math.PI) / 180)}
            y1={10 * Math.sin((deg * Math.PI) / 180)}
            x2={16 * Math.cos((deg * Math.PI) / 180)}
            y2={16 * Math.sin((deg * Math.PI) / 180)}
            stroke="#ffe08a"
            strokeWidth={1.2}
          />
        ))}
        <polyline points="14,-10 58,-44 96,-44" fill="none" stroke="#8b93a8" strokeWidth={1} opacity={0.7} />
        <text x={102} y={-48} fontSize={14} letterSpacing={2.6} fill="#ffe6b8" style={{ fontFamily: "var(--font-display)" }}>
          SOLAR SYSTEM
        </text>
        <text x={102} y={-32} fontSize={9.5} letterSpacing={1.6} fill="#7d8ba6">
          ORION SPUR · 26,000 LY FROM CORE · WE ARE HERE
        </text>
      </g>

      {/* Hubble marker */}
      <g
        className="cosmic-hit"
        transform={`translate(${HUB.x.toFixed(1)} ${HUB.y.toFixed(1)})`}
        onClick={(e) => {
          e.stopPropagation();
          onSelect("hubble");
        }}
        role="button"
        tabIndex={0}
        aria-label="Hubble Space Telescope"
        onKeyDown={(e) => e.key === "Enter" && onSelect("hubble")}
      >
        <line x1={-(HUB.x - SUNP.x) * 0.72} y1={-(HUB.y - SUNP.y) * 0.72} x2={-10} y2={-6} stroke="#8fd3ff" strokeWidth={1} strokeDasharray="2 4" opacity={0.65} />
        <circle r={26} fill="transparent" />
        <circle className={`hit-ring ${selectedId === "hubble" ? "is-on" : ""}`} r={22} fill="none" stroke="#8fd3ff" strokeWidth={1.2} strokeDasharray="3 6" />
        <g transform="rotate(-28)">
          <rect x={-18} y={-2.6} width={9} height={5.2} rx={1} fill="#4c6ef5" />
          <rect x={9} y={-2.6} width={9} height={5.2} rx={1} fill="#4c6ef5" />
          <rect x={-8} y={-4.2} width={16} height={8.4} rx={2.6} fill="#cbd5e1" />
          <circle cx={-8} cy={0} r={2.6} fill="#8fd3ff" />
        </g>
        <text x={26} y={16} fontSize={12} letterSpacing={2.2} fill="#bfe3ff" style={{ fontFamily: "var(--font-display)" }}>
          HUBBLE · HST
        </text>
        <text x={26} y={31} fontSize={9.5} letterSpacing={1.4} fill="#7d8ba6">
          LOW EARTH ORBIT · 535 KM UP — POSITION NOT TO SCALE
        </text>
      </g>

      {/* frame captions */}
      <text x={940} y={78} textAnchor="end" fontSize={10} letterSpacing={2.4} fill="#68768f">
        TOP-DOWN VIEW · GALACTIC NORTH UP
      </text>
      <text x={60} y={905} fontSize={11.5} letterSpacing={2.6} fill="#8fa0bd" style={{ fontFamily: "var(--font-display)" }}>
        MILKY WAY · ~100,000 LIGHT-YEARS ACROSS
      </text>
      <text x={60} y={926} fontSize={9.5} letterSpacing={1.6} fill="#68768f">
        100–400 BILLION STARS · BARRED SPIRAL · 13.6 BILLION YEARS OLD
      </text>
      <g stroke="#68768f" strokeWidth={1}>
        <line x1={770} y1={902} x2={910} y2={902} />
        <line x1={770} y1={897} x2={770} y2={907} />
        <line x1={910} y1={897} x2={910} y2={907} />
      </g>
      <text x={840} y={924} textAnchor="middle" fontSize={9.5} letterSpacing={2} fill="#68768f">
        25,000 LIGHT-YEARS
      </text>
    </svg>
  );
}
