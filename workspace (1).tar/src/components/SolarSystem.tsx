import { useEffect, useState } from "react";
import { PLANETS, SUN, angleAt, type Body } from "../data/bodies";

const C = 500; // center of the 1000x1000 viewBox

interface Props {
  simDays: number;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}

const pos = (orbitR: number, a: number) => ({
  x: C + orbitR * Math.cos(a),
  y: C - orbitR * Math.sin(a),
});

/** trail arc trailing behind the planet (motion is counter-clockwise on screen) */
function trailPath(orbitR: number, aEnd: number, delta: number): string {
  const aStart = aEnd - delta;
  const p1 = pos(orbitR, aStart);
  const p2 = pos(orbitR, aEnd);
  return `M ${p1.x.toFixed(2)} ${p1.y.toFixed(2)} A ${orbitR} ${orbitR} 0 0 0 ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
}

/** dark hemisphere path, facing away from the Sun */
function shadowPath(x: number, y: number, r: number, a: number): string {
  const dx = -Math.cos(a);
  const dy = Math.sin(a);
  const px = -dy;
  const py = dx;
  const ax = x + px * r;
  const ay = y + py * r;
  const bx = x - px * r;
  const by = y - py * r;
  return `M ${ax.toFixed(2)} ${ay.toFixed(2)} A ${r} ${r} 0 0 1 ${bx.toFixed(2)} ${by.toFixed(2)} Z`;
}

const TRAILS: Array<[number, number, number]> = [
  [0.62, 0.1, 1],
  [0.34, 0.2, 0.78],
  [0.15, 0.36, 0.55],
];

function OrbitRing({
  p,
  active,
  color,
}: {
  p: Body;
  active: boolean;
  color: string;
}) {
  return (
    <g>
      <circle
        className="orbit-ring"
        cx={C}
        cy={C}
        r={p.orbitR}
        fill="none"
        stroke={active ? color : "#8fa0bd"}
        strokeOpacity={active ? 0.55 : 0.16}
        strokeWidth={active ? 1.4 : 1}
      />
      <text
        x={C + p.orbitR * 0.7071 + 7}
        y={C - p.orbitR * 0.7071 - 7}
        fontSize={11}
        letterSpacing={1.5}
        fill="#68768f"
        opacity={0.75}
        style={{ fontFamily: "var(--font-body)" }}
      >
        {p.au.toFixed(2)} AU
      </text>
    </g>
  );
}

function PlanetNode({
  p,
  a,
  simDays,
  now,
  selected,
  onSelect,
  onHover,
}: {
  p: Body;
  a: number;
  simDays: number;
  now: number;
  selected: boolean;
  onSelect: () => void;
  onHover: (id: string | null) => void;
}) {
  const { x, y } = pos(p.orbitR, a);
  const r = p.sizeR;
  const hit = Math.max(r + 12, 20);
  const isSaturn = p.id === "saturn";
  const isUranus = p.id === "uranus";
  const isEarth = p.id === "earth";

  /* LEO satellites — true periods (92.9 / 95.7 min), displayed ×120 so the motion reads */
  const ACC = 120;
  const issA = (((now * ACC) % (92.9 * 60000)) / (92.9 * 60000)) * Math.PI * 2;
  const hstA =
    ((((now * ACC) % (95.7 * 60000)) / (95.7 * 60000)) * Math.PI * 2 + 2.3) % (Math.PI * 2);

  return (
    <g
      className={`planet-g ${selected ? "is-selected" : ""}`}
      transform={`translate(${x.toFixed(2)} ${y.toFixed(2)})`}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      onMouseEnter={() => onHover(p.id)}
      onMouseLeave={() => onHover(null)}
      role="button"
      tabIndex={0}
      aria-label={`${p.name} — view details`}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect();
        }
      }}
    >
      <circle r={hit} fill="transparent" />

      <g className="planet-scale">
        {/* back half of rings */}
        {isSaturn && (
          <g transform="rotate(-18)">
            <ellipse rx={r * 1.85} ry={r * 0.62} fill="none" stroke="#c9ae79" strokeOpacity={0.55} strokeWidth={3.4} />
            <ellipse rx={r * 1.45} ry={r * 0.48} fill="none" stroke="#8f7a4c" strokeOpacity={0.5} strokeWidth={2} />
          </g>
        )}
        {isUranus && (
          <g transform="rotate(78)">
            <ellipse rx={r * 1.6} ry={r * 0.42} fill="none" stroke="#9adfe2" strokeOpacity={0.35} strokeWidth={1.6} />
          </g>
        )}

        {/* sphere */}
        <circle r={r} fill={`url(#g-${p.id})`} />

        {/* cloud / band detail */}
        {p.id === "jupiter" && (
          <g clipPath={`url(#clip-${p.id})`} opacity={0.4}>
            <rect x={-r} y={-r * 0.5} width={r * 2} height={r * 0.18} fill="#8a5c30" />
            <rect x={-r} y={-r * 0.12} width={r * 2} height={r * 0.24} fill="#a3703c" />
            <rect x={-r} y={r * 0.32} width={r * 2} height={r * 0.16} fill="#8a5c30" />
            <ellipse cx={r * 0.3} cy={r * 0.42} rx={r * 0.22} ry={r * 0.13} fill="#c4472e" />
          </g>
        )}
        {isSaturn && (
          <g clipPath={`url(#clip-${p.id})`} opacity={0.32}>
            <rect x={-r} y={-r * 0.45} width={r * 2} height={r * 0.2} fill="#9c7f45" />
            <rect x={-r} y={r * 0.1} width={r * 2} height={r * 0.26} fill="#b3955c" />
          </g>
        )}
        {isEarth && (
          <g clipPath={`url(#clip-${p.id})`} opacity={0.55}>
            <ellipse cx={-r * 0.3} cy={-r * 0.25} rx={r * 0.42} ry={r * 0.3} fill="#3f9e5f" />
            <ellipse cx={r * 0.35} cy={r * 0.3} rx={r * 0.36} ry={r * 0.26} fill="#3f9e5f" />
            <ellipse cx={-r * 0.1} cy={r * 0.05} rx={r * 0.5} ry={r * 0.14} fill="#eef6ff" opacity={0.5} />
          </g>
        )}

        {/* day/night terminator, always facing away from the Sun */}
        <path d={shadowPath(0, 0, r, a)} fill="rgba(3,7,18,0.48)" />

        {/* front half of rings */}
        {isSaturn && (
          <g transform="rotate(-18)">
            <path d={`M ${-r * 1.85} 0 A ${r * 1.85} ${r * 0.62} 0 0 0 ${r * 1.85} 0`} fill="none" stroke="#e0c489" strokeOpacity={0.85} strokeWidth={3.4} />
            <path d={`M ${-r * 1.45} 0 A ${r * 1.45} ${r * 0.48} 0 0 0 ${r * 1.45} 0`} fill="none" stroke="#a8905c" strokeOpacity={0.7} strokeWidth={2} />
          </g>
        )}
        {isUranus && (
          <g transform="rotate(78)">
            <path d={`M ${-r * 1.6} 0 A ${r * 1.6} ${r * 0.42} 0 0 0 ${r * 1.6} 0`} fill="none" stroke="#bff0f2" strokeOpacity={0.5} strokeWidth={1.6} />
          </g>
        )}

        {/* the Moon — real 27.3-day sidereal period */}
        {isEarth && (
          <circle
            cx={21.5 * Math.cos((simDays / 27.32) * Math.PI * 2)}
            cy={-21.5 * Math.sin((simDays / 27.32) * Math.PI * 2)}
            r={2.4}
            fill="#cdd3de"
          />
        )}
      </g>

      {/* ISS + Hubble in live orbital motion around Earth */}
      {isEarth && (
        <g>
          <circle r={13} fill="none" stroke="#2dd4bf" strokeOpacity={0.28} strokeWidth={0.8} />
          <circle
            cx={13 * Math.cos(issA)}
            cy={-13 * Math.sin(issA)}
            r={1.8}
            fill="#2dd4bf"
            style={{ filter: "drop-shadow(0 0 3px rgba(45,212,191,0.9))" }}
          />
          <circle
            r={17.5}
            fill="none"
            stroke="#fbbf24"
            strokeOpacity={0.24}
            strokeWidth={0.8}
            strokeDasharray="2.5 3"
          />
          <circle
            cx={17.5 * Math.cos(hstA)}
            cy={-17.5 * Math.sin(hstA)}
            r={1.6}
            fill="#fbbf24"
            style={{ filter: "drop-shadow(0 0 3px rgba(251,191,36,0.9))" }}
          />
          <text
            y={r + 31}
            textAnchor="middle"
            fontSize={8}
            letterSpacing={2.2}
            fill="#5f7089"
            opacity={0.85}
            pointerEvents="none"
          >
            ISS · HST ×120
          </text>
        </g>
      )}

      {selected && (
        <circle
          className="sel-ring"
          r={r + 11}
          fill="none"
          stroke={p.color}
          strokeWidth={1.3}
          strokeDasharray="3 7"
          strokeLinecap="round"
          opacity={0.95}
        />
      )}

      <text
        className="planet-label"
        y={-(r + 15)}
        textAnchor="middle"
        fontSize={13.5}
        letterSpacing={2.5}
        fill="#f3ecdc"
        style={{ textTransform: "uppercase" }}
      >
        {p.name}
      </text>
    </g>
  );
}

export default function SolarSystem({ simDays, selectedId, onSelect }: Props) {
  const [hoverId, setHoverId] = useState<string | null>(null);

  /* real-time clock for the LEO satellites around Earth (ISS 92.9 min, HST 95.7 min) */
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const id = window.setInterval(() => setNow(Date.now()), 400);
    return () => window.clearInterval(id);
  }, []);

  return (
    <svg
      className="absolute inset-0 z-10 h-full w-full"
      viewBox="0 0 1000 1000"
      preserveAspectRatio="xMidYMid meet"
      onClick={() => onSelect(null)}
      role="img"
      aria-label="Solar system map — the Sun and eight orbiting planets"
    >
      <defs>
        {PLANETS.map((p) => (
          <radialGradient key={p.id} id={`g-${p.id}`} cx="33%" cy="30%" r="78%">
            <stop offset="0%" stopColor={p.light} />
            <stop offset="55%" stopColor={p.color} />
            <stop offset="100%" stopColor={p.dark} />
          </radialGradient>
        ))}
        {PLANETS.map((p) => (
          <clipPath key={`clip-${p.id}`} id={`clip-${p.id}`}>
            <circle r={p.sizeR} />
          </clipPath>
        ))}
        <radialGradient id="g-sun-core" cx="42%" cy="40%" r="75%">
          <stop offset="0%" stopColor="#fffbe8" />
          <stop offset="38%" stopColor="#ffe08a" />
          <stop offset="75%" stopColor="#ffb43a" />
          <stop offset="100%" stopColor="#ff7a1f" />
        </radialGradient>
        <radialGradient id="sun-corona" cx="50%" cy="50%" r="50%">
          <stop offset="55%" stopColor="rgba(255,170,60,0.55)" />
          <stop offset="100%" stopColor="rgba(255,120,30,0)" />
        </radialGradient>
        <radialGradient id="sun-halo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(255,190,90,0.28)" />
          <stop offset="45%" stopColor="rgba(255,150,50,0.10)" />
          <stop offset="100%" stopColor="rgba(255,140,40,0)" />
        </radialGradient>
      </defs>

      {/* orbit rings + AU markers */}
      {PLANETS.map((p) => (
        <OrbitRing key={p.id} p={p} active={hoverId === p.id || selectedId === p.id} color={p.color} />
      ))}

      {/* asteroid belt */}
      <g className="orbit-spin" opacity={0.5}>
        <circle cx={C} cy={C} r={240} fill="none" stroke="#78879f" strokeOpacity={0.3} strokeWidth={7} strokeDasharray="1.2 11" />
        <circle cx={C} cy={C} r={248} fill="none" stroke="#78879f" strokeOpacity={0.18} strokeWidth={4} strokeDasharray="1 15" />
      </g>

      {/* motion trails */}
      {PLANETS.map((p) => {
        const a = angleAt(p, simDays);
        return (
          <g key={`trail-${p.id}`}>
            {TRAILS.map(([delta, widthF, op], i) => (
              <path
                key={i}
                d={trailPath(p.orbitR, a, delta)}
                fill="none"
                stroke={p.color}
                strokeOpacity={op * 0.5}
                strokeWidth={Math.max(p.sizeR * widthF, 1.4)}
                strokeLinecap="round"
              />
            ))}
          </g>
        );
      })}

      {/* the Sun */}
      <g
        className="planet-g"
        onClick={(e) => {
          e.stopPropagation();
          onSelect("sun");
        }}
        role="button"
        tabIndex={0}
        aria-label="The Sun — view details"
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onSelect("sun");
          }
        }}
      >
        <circle cx={C} cy={C} r={170} fill="url(#sun-halo)" className="sun-glow-anim" pointerEvents="none" />
        <g className="rays-anim" pointerEvents="none" opacity={0.5}>
          {Array.from({ length: 12 }, (_, i) => {
            const a = (i / 12) * Math.PI * 2;
            return (
              <line
                key={i}
                x1={C + 60 * Math.cos(a)}
                y1={C - 60 * Math.sin(a)}
                x2={C + 200 * Math.cos(a)}
                y2={C - 200 * Math.sin(a)}
                stroke="#ffc36b"
                strokeOpacity={0.07}
                strokeWidth={2}
              />
            );
          })}
        </g>
        <circle cx={C} cy={C} r={78} fill="url(#sun-corona)" className="corona-anim" pointerEvents="none" />
        <circle cx={C} cy={C} r={SUN.sizeR} fill="url(#g-sun-core)" />
        {selectedId === "sun" && (
          <circle
            className="sel-ring"
            cx={C}
            cy={C}
            r={SUN.sizeR + 10}
            fill="none"
            stroke="#ffcf7a"
            strokeWidth={1.3}
            strokeDasharray="3 7"
            strokeLinecap="round"
          />
        )}
        <text
          className="planet-label"
          x={C}
          y={C - SUN.sizeR - 16}
          textAnchor="middle"
          fontSize={13.5}
          letterSpacing={2.5}
          fill="#ffe6b8"
          style={{ opacity: selectedId === "sun" ? 1 : undefined }}
        >
          SOL
        </text>
        <circle cx={C} cy={C} r={52} fill="transparent" />
      </g>

      {/* planets */}
      {PLANETS.map((p) => (
        <PlanetNode
          key={p.id}
          p={p}
          a={angleAt(p, simDays)}
          simDays={simDays}
          now={now}
          selected={selectedId === p.id}
          onSelect={() => onSelect(p.id)}
          onHover={setHoverId}
        />
      ))}
    </svg>
  );
}
