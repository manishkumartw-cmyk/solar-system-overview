import { useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Stars, Html, Billboard } from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import * as THREE from "three";
import { PLANETS, angleAt, type Body } from "../data/bodies";

const ORBIT_SCALE = 0.5;
const SIZE_SCALE = 0.85;
const SUN_R = 15;

function makeGlowTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, "rgba(255,246,216,1)");
  g.addColorStop(0.22, "rgba(255,204,110,0.6)");
  g.addColorStop(0.5, "rgba(255,150,60,0.2)");
  g.addColorStop(1, "rgba(255,120,40,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(c);
}

function SunMesh({
  selected,
  onSelect,
  pulse,
}: {
  selected: boolean;
  onSelect: (id: string) => void;
  pulse: boolean;
}) {
  const glow = useMemo(makeGlowTexture, []);
  const spriteRef = useRef<THREE.Sprite>(null);
  const [hover, setHover] = useState(false);

  useFrame(({ clock }) => {
    if (!pulse || !spriteRef.current) return;
    const s = 118 + Math.sin(clock.getElapsedTime() * 1.6) * 8;
    spriteRef.current.scale.set(s, s, 1);
  });

  const hot = selected || hover;

  return (
    <group>
      <sprite ref={spriteRef} scale={[118, 118, 1]}>
        <spriteMaterial map={glow} blending={THREE.AdditiveBlending} depthWrite={false} transparent opacity={0.95} />
      </sprite>
      <mesh
        onClick={(e) => {
          e.stopPropagation();
          onSelect("sun");
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          setHover(true);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHover(false);
          document.body.style.cursor = "auto";
        }}
      >
        <sphereGeometry args={[SUN_R, 56, 56]} />
        <meshBasicMaterial color={hot ? "#ffdd8f" : "#ffcf6b"} />
      </mesh>
      {selected && (
        <Billboard>
          <mesh>
            <ringGeometry args={[SUN_R + 3, SUN_R + 3.6, 72]} />
            <meshBasicMaterial color="#ffcf7a" transparent opacity={0.9} side={THREE.DoubleSide} />
          </mesh>
        </Billboard>
      )}
      <Html center distanceFactor={300} position={[0, SUN_R + 9, 0]} zIndexRange={[24, 0]} className="label3d-wrap">
        <div className={`label3d ${hot ? "label3d-hot" : ""}`} style={hot ? { color: "#ffe2a8" } : undefined}>
          SOL
        </div>
      </Html>
    </group>
  );
}

function OrbitRing3D({ radius, color, active }: { radius: number; color: string; active: boolean }) {
  return (
    <mesh rotation-x={-Math.PI / 2}>
      <ringGeometry args={[radius - 0.22, radius + 0.22, 200]} />
      <meshBasicMaterial
        color={active ? color : "#66748f"}
        transparent
        opacity={active ? 0.75 : 0.26}
        side={THREE.DoubleSide}
        depthWrite={false}
      />
    </mesh>
  );
}

function AsteroidBelt({ simDays }: { simDays: number }) {
  const geom = useMemo(() => {
    const n = 750;
    const arr = new Float32Array(n * 3);
    let seed = 20260214;
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < n; i++) {
      const ang = rnd() * Math.PI * 2;
      const rad = 118 + (rnd() - 0.5) * 17;
      arr[i * 3] = rad * Math.cos(ang);
      arr[i * 3 + 1] = (rnd() - 0.5) * 4.5;
      arr[i * 3 + 2] = -rad * Math.sin(ang);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(arr, 3));
    return g;
  }, []);
  return (
    <points geometry={geom} rotation-y={simDays * 0.0006}>
      <pointsMaterial color="#93a0b8" size={0.9} sizeAttenuation transparent opacity={0.5} depthWrite={false} />
    </points>
  );
}

function Planet3D({
  p,
  simDays,
  selected,
  onSelect,
}: {
  p: Body;
  simDays: number;
  selected: boolean;
  onSelect: (id: string) => void;
}) {
  const [hover, setHover] = useState(false);
  const a = angleAt(p, simDays);
  const R = p.orbitR * ORBIT_SCALE;
  const r = Math.max(p.sizeR * SIZE_SCALE, 2.2);
  const x = R * Math.cos(a);
  const z = -R * Math.sin(a);
  const hot = selected || hover;
  const isSaturn = p.id === "saturn";
  const isUranus = p.id === "uranus";
  const isEarth = p.id === "earth";
  const moonA = (simDays / 27.32) * Math.PI * 2;

  return (
    <group position={[x, 0, z]}>
      <mesh
        rotation-y={a * 4}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(p.id);
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          setHover(true);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHover(false);
          document.body.style.cursor = "auto";
        }}
      >
        <sphereGeometry args={[r, 48, 48]} />
        <meshStandardMaterial
          color={p.color}
          roughness={0.78}
          metalness={0.06}
          emissive={p.dark}
          emissiveIntensity={hot ? 0.42 : 0.14}
        />
      </mesh>

      {isSaturn && (
        <mesh rotation={[-Math.PI / 2 + 0.42, 0, 0]}>
          <ringGeometry args={[r * 1.35, r * 1.92, 96]} />
          <meshBasicMaterial color="#dcc08a" transparent opacity={hot ? 0.85 : 0.62} side={THREE.DoubleSide} />
        </mesh>
      )}
      {isUranus && (
        <mesh rotation={[-Math.PI / 2 + 1.35, 0, 0]}>
          <ringGeometry args={[r * 1.45, r * 1.58, 96]} />
          <meshBasicMaterial color="#9adfe2" transparent opacity={0.38} side={THREE.DoubleSide} />
        </mesh>
      )}
      {isEarth && (
        <mesh position={[9.5 * Math.cos(moonA), 1.1, -9.5 * Math.sin(moonA)]}>
          <sphereGeometry args={[1.15, 20, 20]} />
          <meshStandardMaterial color="#cdd3de" roughness={1} />
        </mesh>
      )}

      {selected && (
        <Billboard>
          <mesh>
            <ringGeometry args={[r + 2.6, r + 3.15, 72]} />
            <meshBasicMaterial color={p.color} transparent opacity={0.9} side={THREE.DoubleSide} />
          </mesh>
        </Billboard>
      )}

      <Html center distanceFactor={300} position={[0, r + 5, 0]} zIndexRange={[24, 0]} className="label3d-wrap">
        <div className={`label3d ${hot ? "label3d-hot" : ""}`} style={hot ? { color: p.light } : undefined}>
          {p.name}
        </div>
      </Html>
    </group>
  );
}

interface Props {
  simDays: number;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  reducedMotion: boolean;
}

export default function SolarSystem3D({ simDays, selectedId, onSelect, reducedMotion }: Props) {
  const controlsRef = useRef<OrbitControlsImpl | null>(null);
  const [autoOrbit, setAutoOrbit] = useState(!reducedMotion);

  return (
    <div className="absolute inset-0 z-10">
      <Canvas
        camera={{ position: [0, 230, 520], fov: 46, near: 0.1, far: 4000 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
        onPointerMissed={() => onSelect(null)}
      >
        <ambientLight intensity={0.18} />
        <pointLight position={[0, 0, 0]} intensity={2.6} decay={0} color="#fff2d0" />
        <Stars radius={1100} depth={240} count={4200} factor={6} saturation={0} fade speed={reducedMotion ? 0 : 0.5} />

        <SunMesh selected={selectedId === "sun"} onSelect={onSelect} pulse={!reducedMotion} />

        {PLANETS.map((p) => (
          <OrbitRing3D
            key={`ring-${p.id}`}
            radius={p.orbitR * ORBIT_SCALE}
            color={p.color}
            active={selectedId === p.id}
          />
        ))}

        <AsteroidBelt simDays={simDays} />

        {PLANETS.map((p) => (
          <Planet3D key={p.id} p={p} simDays={simDays} selected={selectedId === p.id} onSelect={onSelect} />
        ))}

        <OrbitControls
          ref={controlsRef}
          enablePan={false}
          enableDamping
          dampingFactor={0.08}
          minDistance={42}
          maxDistance={760}
          autoRotate={autoOrbit && !reducedMotion}
          autoRotateSpeed={0.55}
        />
      </Canvas>

      {/* camera cluster */}
      <div className="absolute left-4 top-44 z-20 flex flex-col items-start gap-2 sm:left-6">
        <button className={`cam-btn ${autoOrbit ? "cam-btn-on" : ""}`} onClick={() => setAutoOrbit((v) => !v)}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <circle cx="12" cy="12" r="3.2" />
            <path d="M20.3 8.5c1.6 3.9-2.6 9.6-9.4 12.2M3.7 15.5C2.1 11.6 6.3 5.9 13.1 3.3" strokeLinecap="round" />
            <path d="M13.5 1.2l-.4 2.1 2.1.4M10.5 22.8l.4-2.1-2.1-.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          360° ORBIT · {autoOrbit ? "ON" : "OFF"}
        </button>
        <button className="cam-btn" onClick={() => controlsRef.current?.reset()}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="M3 12a9 9 0 1 0 3-6.7" strokeLinecap="round" />
            <path d="M3 4v5h5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          RESET VIEW
        </button>
      </div>

      <p className="pointer-events-none absolute bottom-[104px] left-1/2 z-20 -translate-x-1/2 whitespace-nowrap font-display text-[10px] font-bold tracking-[0.3em] text-slate-500">
        DRAG TO ORBIT · SCROLL TO ZOOM · CLICK A WORLD
      </p>
    </div>
  );
}
