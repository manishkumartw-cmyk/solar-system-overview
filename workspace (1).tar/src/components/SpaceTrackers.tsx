import { useEffect, useRef, useState } from "react";

type SatId = "iss" | "hst";
type Mode = "live" | "sim";

interface SatCfg {
  name: string;
  label: string;
  color: string;
  dim: string;
  periodMin: number;
  incDeg: number;
  raanDeg: number;
  u0: number;
  altBase: number;
  velBase: number;
  apiId: number;
}

const SATS: Record<SatId, SatCfg> = {
  iss: {
    name: "ISS · ZARYA",
    label: "ISS",
    color: "#2dd4bf",
    dim: "rgba(45,212,191,0.55)",
    periodMin: 92.9,
    incDeg: 51.64,
    raanDeg: 0,
    u0: 0,
    altBase: 417.5,
    velBase: 27566,
    apiId: 25544,
  },
  hst: {
    name: "HUBBLE · HST",
    label: "HST",
    color: "#fbbf24",
    dim: "rgba(251,191,36,0.55)",
    periodMin: 95.7,
    incDeg: 28.47,
    raanDeg: -62,
    u0: 2.3,
    altBase: 535,
    velBase: 27292,
    apiId: 20580,
  },
};

interface SatState {
  lat: number;
  lon: number;
  altKm: number;
  velKmh: number;
  footprintKm: number | null;
  mode: Mode;
}

const SIDEREAL_MS = 86164000;

/** circular-orbit ground-track model (fallback + track geometry) */
function groundPos(cfg: SatCfg, now: number) {
  const periodMs = cfg.periodMin * 60000;
  const u = cfg.u0 + ((now % periodMs) / periodMs) * Math.PI * 2;
  const inc = (cfg.incDeg * Math.PI) / 180;
  const lat = (Math.asin(Math.sin(inc) * Math.sin(u)) * 180) / Math.PI;
  let lon = (Math.atan2(Math.cos(inc) * Math.sin(u), Math.cos(u)) * 180) / Math.PI;
  lon += cfg.raanDeg - ((now % SIDEREAL_MS) / SIDEREAL_MS) * 360;
  lon = ((lon + 540) % 360) - 180;
  return {
    lat,
    lon,
    altKm: cfg.altBase + (cfg.altBase * 0.011) * Math.sin(u * 2 + 0.8),
    velKmh: cfg.velBase + 22 * Math.sin(u + 0.4),
  };
}

const MAP_W = 262;
const MAP_H = 131;
const project = (lat: number, lon: number) => ({
  x: ((lon + 180) / 360) * MAP_W,
  y: ((90 - lat) / 180) * MAP_H,
});

function trackPath(cfg: SatCfg, now: number): string {
  const periodMs = cfg.periodMin * 60000;
  let d = "";
  let prevLon: number | null = null;
  const N = 200;
  for (let i = 0; i <= N; i++) {
    const s = groundPos(cfg, now + (i / N) * periodMs);
    const { x, y } = project(s.lat, s.lon);
    const jump = prevLon !== null && Math.abs(s.lon - prevLon) > 180;
    d += `${i === 0 || jump ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    prevLon = s.lon;
  }
  return d;
}

const fmtLat = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? "N" : "S"}`;
const fmtLon = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? "E" : "W"}`;

const ID_LIST: SatId[] = ["iss", "hst"];

export default function SpaceTrackers({ visible }: { visible: boolean }) {
  const modeRef = useRef<Record<SatId, Mode>>({ iss: "sim", hst: "sim" });
  const [nowTs, setNowTs] = useState(() => Date.now());
  const [sats, setSats] = useState<Record<SatId, SatState>>(() => ({
    iss: { ...groundPos(SATS.iss, Date.now()), footprintKm: null, mode: "sim" },
    hst: { ...groundPos(SATS.hst, Date.now()), footprintKm: null, mode: "sim" },
  }));

  useEffect(() => {
    let stopped = false;
    let pollTimer = 0;

    /* keep the model + track geometry ticking every second */
    const simTick = window.setInterval(() => {
      setNowTs(Date.now());
      setSats((prev) => {
        const t = Date.now();
        const next = { ...prev };
        let changed = false;
        for (const id of ID_LIST) {
          if (modeRef.current[id] === "sim") {
            next[id] = { ...groundPos(SATS[id], t), footprintKm: null, mode: "sim" };
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 1000);

    /* poll the live feed for both spacecraft */
    const poll = async () => {
      const results = await Promise.allSettled(
        ID_LIST.map((id) =>
          fetch(`https://api.wheretheiss.at/v1/satellites/${SATS[id].apiId}`).then((r) => {
            if (!r.ok) throw new Error("api");
            return r.json() as Promise<{
              latitude: number;
              longitude: number;
              altitude: number;
              velocity: number;
              footprint: number;
            }>;
          })
        )
      );
      if (stopped) return;
      setSats((prev) => {
        const next = { ...prev };
        results.forEach((res, idx) => {
          const id = ID_LIST[idx];
          if (res.status === "fulfilled") {
            modeRef.current[id] = "live";
            next[id] = {
              lat: res.value.latitude,
              lon: res.value.longitude,
              altKm: res.value.altitude,
              velKmh: res.value.velocity,
              footprintKm: res.value.footprint,
              mode: "live",
            };
          } else {
            modeRef.current[id] = "sim";
            next[id] = { ...groundPos(SATS[id], Date.now()), footprintKm: null, mode: "sim" };
          }
        });
        return next;
      });
      pollTimer = window.setTimeout(poll, 5000);
    };
    poll();

    return () => {
      stopped = true;
      window.clearInterval(simTick);
      window.clearTimeout(pollTimer);
    };
  }, []);

  const tracks = ID_LIST.map((id) => trackPath(SATS[id], nowTs));

  return (
    <aside
      className={`absolute bottom-6 left-6 z-40 hidden w-[318px] transition-all duration-500 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] md:block ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-5 opacity-0"
      }`}
      aria-label="Live low-Earth-orbit tracker — ISS and Hubble"
    >
      <div className="rounded-xl border border-teal-200/15 bg-[#08121a]/90 p-4 shadow-[0_24px_60px_rgba(0,0,0,0.5)] backdrop-blur-md">
        <div className="flex items-center justify-between">
          <p className="font-display text-[10px] font-bold tracking-[0.3em] text-teal-200/90">
            LEO LIVE TRACK
          </p>
          <span className="text-[8.5px] font-semibold tracking-[0.2em] text-slate-500">
            ISS + HUBBLE
          </span>
        </div>

        {/* shared ground-track map */}
        <div className="mt-3 overflow-hidden rounded-lg border border-white/[0.07]">
          <svg viewBox={`0 0 ${MAP_W} ${MAP_H}`} className="block w-full" role="img" aria-label="Ground tracks of the ISS and the Hubble Space Telescope">
            <rect width={MAP_W} height={MAP_H} fill="#06141c" />
            {Array.from({ length: 11 }, (_, i) => (
              <line key={`v${i}`} x1={((i + 1) * MAP_W) / 12} y1={0} x2={((i + 1) * MAP_W) / 12} y2={MAP_H} stroke="#1b3a47" strokeWidth={0.6} />
            ))}
            {Array.from({ length: 5 }, (_, i) => (
              <line
                key={`h${i}`}
                x1={0}
                y1={((i + 1) * MAP_H) / 6}
                x2={MAP_W}
                y2={((i + 1) * MAP_H) / 6}
                stroke={i === 2 ? "#2b5568" : "#1b3a47"}
                strokeWidth={i === 2 ? 0.9 : 0.6}
              />
            ))}
            {ID_LIST.map((id, i) => (
              <path key={`t-${id}`} d={tracks[i]} fill="none" stroke={SATS[id].color} strokeOpacity={0.42} strokeWidth={1.05} />
            ))}
            {ID_LIST.map((id) => {
              const s = sats[id];
              const p = project(s.lat, s.lon);
              const c = SATS[id].color;
              return (
                <g key={`m-${id}`} transform={`translate(${p.x.toFixed(1)} ${p.y.toFixed(1)})`}>
                  <circle className="iss-ping" r={6.5} fill="none" stroke={c} strokeWidth={1.2} />
                  <line x1={-8.5} x2={-4} y1={0} y2={0} stroke={c} strokeWidth={1} />
                  <line x1={4} x2={8.5} y1={0} y2={0} stroke={c} strokeWidth={1} />
                  <line y1={-8.5} y2={-4} x1={0} x2={0} stroke={c} strokeWidth={1} />
                  <line y1={4} y2={8.5} x1={0} x2={0} stroke={c} strokeWidth={1} />
                  <circle r={2.4} fill={c} />
                  <text x={9} y={-6} fontSize={7.5} fontWeight={700} letterSpacing={1.2} fill={c} style={{ fontFamily: "var(--font-display)" }}>
                    {SATS[id].label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* per-spacecraft rows */}
        <div className="mt-3 space-y-2.5">
          {ID_LIST.map((id) => {
            const s = sats[id];
            const cfg = SATS[id];
            const live = s.mode === "live";
            return (
              <div key={id} className="rounded-lg border border-white/[0.06] bg-white/[0.03] px-3 py-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: cfg.color, boxShadow: `0 0 8px ${cfg.color}` }} />
                    <span className="font-display text-[9.5px] font-bold tracking-[0.22em] text-slate-200">
                      {cfg.name}
                    </span>
                  </span>
                  <span
                    className={`rounded-full border px-1.5 py-px text-[8px] font-bold tracking-[0.16em] ${
                      live ? "border-emerald-300/30 text-emerald-300" : "border-amber-300/30 text-amber-300"
                    }`}
                  >
                    {live ? "LIVE" : "SIM"}
                  </span>
                </div>
                <div className="mt-1.5 flex items-baseline justify-between">
                  <span className="font-display text-[21px] font-extrabold leading-none text-[#eafffa]">
                    {Math.round(s.velKmh).toLocaleString("en-US")}
                    <span className="ml-1.5 text-[10px] font-semibold text-slate-400">km/h</span>
                  </span>
                  <span className="font-display text-[10px] text-slate-400">
                    {(s.velKmh / 3600).toFixed(2)} km/s
                  </span>
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[9px] tracking-wide text-slate-500">
                  <span>
                    {fmtLat(s.lat)}&ensp;{fmtLon(s.lon)}
                  </span>
                  <span>
                    ALT {s.altKm.toFixed(0)} KM{s.footprintKm ? ` · FP ${Math.round(s.footprintKm).toLocaleString("en-US")} KM` : ""}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <p className="mt-3 border-t border-white/[0.07] pt-2.5 text-[9px] leading-relaxed tracking-wide text-slate-500">
          ORBITS 92.9 / 95.7 MIN · INC 51.6° / 28.5° · FEED wheretheiss.at · 5 s REFRESH · SIM =
          PROPAGATED MODEL WHEN OFFLINE
        </p>
      </div>
    </aside>
  );
}
