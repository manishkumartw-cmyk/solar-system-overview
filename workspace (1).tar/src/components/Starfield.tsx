import { useMemo, type CSSProperties } from "react";

interface Star {
  x: number;
  y: number;
  r: number;
  o: number;
  twinkle: boolean;
  dur: number;
  delay: number;
}

/** deterministic PRNG so the sky is stable across renders */
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeStars(seed: number, count: number, rMin: number, rMax: number): Star[] {
  const rnd = mulberry32(seed);
  return Array.from({ length: count }, () => ({
    x: rnd() * 1600,
    y: rnd() * 900,
    r: rMin + rnd() * (rMax - rMin),
    o: 0.2 + rnd() * 0.6,
    twinkle: rnd() > 0.45,
    dur: 2.4 + rnd() * 4.5,
    delay: rnd() * 6,
  }));
}

export default function Starfield() {
  const far = useMemo(() => makeStars(11, 150, 0.5, 1.1), []);
  const mid = useMemo(() => makeStars(23, 65, 1.0, 1.8), []);
  const bright = useMemo(() => makeStars(37, 16, 1.8, 2.6), []);

  const layer = (stars: Star[], keyPrefix: string) =>
    stars.map((s, i) => (
      <circle
        key={`${keyPrefix}-${i}`}
        cx={s.x}
        cy={s.y}
        r={s.r}
        fill="#dbe6ff"
        opacity={s.o}
        className={s.twinkle ? "tw" : undefined}
        style={
          s.twinkle
            ? ({ "--d": `${s.dur.toFixed(2)}s`, "--dl": `${s.delay.toFixed(2)}s` } as CSSProperties)
            : undefined
        }
      />
    ));

  return (
    <svg
      className="absolute inset-0 h-full w-full"
      viewBox="0 0 1600 900"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
    >
      <g className="star-drift-a">{layer(far, "f")}</g>
      <g className="star-drift-b">{layer(mid, "m")}</g>
      <g className="star-drift-a">
        {bright.map((s, i) => (
          <g key={`b-${i}`}>
            <circle cx={s.x} cy={s.y} r={s.r * 3.2} fill="#bcd2ff" opacity={0.08} />
            <circle
              cx={s.x}
              cy={s.y}
              r={s.r}
              fill="#f4f8ff"
              opacity={s.o}
              className="tw"
              style={{ "--d": `${s.dur.toFixed(2)}s`, "--dl": `${s.delay.toFixed(2)}s` } as CSSProperties}
            />
          </g>
        ))}
      </g>
    </svg>
  );
}
