export interface Stat {
  label: string;
  value: string;
}

export interface Body {
  id: string;
  name: string;
  index: string; // display number, e.g. "03"
  type: string; // "G-type star", "Terrestrial planet"...
  color: string; // base
  light: string; // lit side
  dark: string; // shadow side
  orbitR: number; // display orbit radius in viewBox units
  sizeR: number; // display radius
  periodDays: number; // sidereal orbital period
  angle0: number; // starting phase (rad)
  au: number; // real distance from Sun in AU (0 for Sun)
  diameterKm: number;
  stats: Stat[];
  blurb: string;
}

export const SUN: Body = {
  id: "sun",
  name: "Sun",
  index: "00",
  type: "G-type main-sequence star",
  color: "#ffb43a",
  light: "#fff3c4",
  dark: "#ff7a1f",
  orbitR: 0,
  sizeR: 42,
  periodDays: 0,
  angle0: 0,
  au: 0,
  diameterKm: 1392700,
  stats: [
    { label: "Diameter", value: "1,392,700 km" },
    { label: "Surface temp", value: "5,505 °C" },
    { label: "Rotation", value: "25.4 days" },
    { label: "Mass share", value: "99.86 %" },
    { label: "Spectral class", value: "G2V" },
    { label: "Age", value: "4.6 bn yrs" },
  ],
  blurb:
    "Every second the Sun fuses roughly 600 million tonnes of hydrogen into helium, releasing the light that powers every orbit you see here. It holds 99.86 % of the Solar System's mass.",
};

export const PLANETS: Body[] = [
  {
    id: "mercury",
    name: "Mercury",
    index: "01",
    type: "Terrestrial planet",
    color: "#a08c78",
    light: "#d8c8b8",
    dark: "#574b40",
    orbitR: 80,
    sizeR: 5,
    periodDays: 87.97,
    angle0: 0.9,
    au: 0.387,
    diameterKm: 4879,
    stats: [
      { label: "Diameter", value: "4,879 km" },
      { label: "Distance", value: "57.9M km · 0.39 AU" },
      { label: "Orbital period", value: "88.0 days" },
      { label: "Orbital speed", value: "47.4 km/s" },
      { label: "Moons", value: "0" },
      { label: "Day length", value: "58.6 Earth days" },
    ],
    blurb:
      "The smallest planet races around the Sun faster than any other — a full lap in just 88 days — yet its solar day, sunrise to sunrise, lasts 176 Earth days.",
  },
  {
    id: "venus",
    name: "Venus",
    index: "02",
    type: "Terrestrial planet",
    color: "#e6c26a",
    light: "#ffe9b0",
    dark: "#8a6a2e",
    orbitR: 118,
    sizeR: 8,
    periodDays: 224.7,
    angle0: 2.4,
    au: 0.723,
    diameterKm: 12104,
    stats: [
      { label: "Diameter", value: "12,104 km" },
      { label: "Distance", value: "108.2M km · 0.72 AU" },
      { label: "Orbital period", value: "224.7 days" },
      { label: "Orbital speed", value: "35.0 km/s" },
      { label: "Moons", value: "0" },
      { label: "Surface temp", value: "465 °C" },
    ],
    blurb:
      "Venus spins backwards beneath crushing clouds of CO₂, making it the hottest world in the system — hot enough to melt lead — even though Mercury sits closer to the Sun.",
  },
  {
    id: "earth",
    name: "Earth",
    index: "03",
    type: "Terrestrial planet",
    color: "#3f7fd4",
    light: "#9fd8ff",
    dark: "#142c55",
    orbitR: 156,
    sizeR: 8.5,
    periodDays: 365.25,
    angle0: 4.2,
    au: 1.0,
    diameterKm: 12742,
    stats: [
      { label: "Diameter", value: "12,742 km" },
      { label: "Distance", value: "149.6M km · 1.00 AU" },
      { label: "Orbital period", value: "365.25 days" },
      { label: "Orbital speed", value: "29.8 km/s" },
      { label: "Moons", value: "1" },
      { label: "Mean temp", value: "15 °C" },
    ],
    blurb:
      "The only world known to host life. Liquid water covers 71 % of its surface, and its large Moon steadies the axial tilt that gives us seasons.",
  },
  {
    id: "mars",
    name: "Mars",
    index: "04",
    type: "Terrestrial planet",
    color: "#d1603d",
    light: "#ffb08a",
    dark: "#66260f",
    orbitR: 198,
    sizeR: 6.5,
    periodDays: 686.98,
    angle0: 5.6,
    au: 1.524,
    diameterKm: 6779,
    stats: [
      { label: "Diameter", value: "6,779 km" },
      { label: "Distance", value: "227.9M km · 1.52 AU" },
      { label: "Orbital period", value: "687.0 days" },
      { label: "Orbital speed", value: "24.1 km/s" },
      { label: "Moons", value: "2" },
      { label: "Highest peak", value: "Olympus Mons, 21.9 km" },
    ],
    blurb:
      "Rust-red from iron oxide dust, Mars hosts the tallest volcano and the deepest canyons in the Solar System — and the rovers currently hunting for ancient life.",
  },
  {
    id: "jupiter",
    name: "Jupiter",
    index: "05",
    type: "Gas giant",
    color: "#c99a62",
    light: "#f0d0a0",
    dark: "#63401d",
    orbitR: 288,
    sizeR: 21,
    periodDays: 4332.6,
    angle0: 1.3,
    au: 5.203,
    diameterKm: 139820,
    stats: [
      { label: "Diameter", value: "139,820 km" },
      { label: "Distance", value: "778.5M km · 5.20 AU" },
      { label: "Orbital period", value: "11.9 years" },
      { label: "Orbital speed", value: "13.1 km/s" },
      { label: "Moons", value: "95" },
      { label: "Day length", value: "9.9 hours" },
    ],
    blurb:
      "More massive than all other planets combined. The Great Red Spot — a storm wider than Earth — has been raging in its cloud bands for at least 190 years.",
  },
  {
    id: "saturn",
    name: "Saturn",
    index: "06",
    type: "Gas giant",
    color: "#d9bc7f",
    light: "#f5e3b3",
    dark: "#6f5527",
    orbitR: 342,
    sizeR: 17,
    periodDays: 10759,
    angle0: 3.5,
    au: 9.537,
    diameterKm: 116460,
    stats: [
      { label: "Diameter", value: "116,460 km" },
      { label: "Distance", value: "1,434M km · 9.54 AU" },
      { label: "Orbital period", value: "29.4 years" },
      { label: "Orbital speed", value: "9.7 km/s" },
      { label: "Moons", value: "146" },
      { label: "Ring span", value: "~280,000 km" },
    ],
    blurb:
      "Its dazzling rings span 280,000 km yet are mostly less than a kilometre thick — countless shards of ice shepherded by tiny moonlets.",
  },
  {
    id: "uranus",
    name: "Uranus",
    index: "07",
    type: "Ice giant",
    color: "#7fc8cc",
    light: "#d8f4f4",
    dark: "#245c63",
    orbitR: 398,
    sizeR: 12,
    periodDays: 30688,
    angle0: 0.4,
    au: 19.191,
    diameterKm: 50724,
    stats: [
      { label: "Diameter", value: "50,724 km" },
      { label: "Distance", value: "2,871M km · 19.2 AU" },
      { label: "Orbital period", value: "84.0 years" },
      { label: "Orbital speed", value: "6.8 km/s" },
      { label: "Moons", value: "28" },
      { label: "Axial tilt", value: "97.8°" },
    ],
    blurb:
      "Knocked almost fully onto its side long ago, Uranus rolls around the Sun — each pole gets 42 years of continuous daylight, then 42 years of night.",
  },
  {
    id: "neptune",
    name: "Neptune",
    index: "08",
    type: "Ice giant",
    color: "#4a66c8",
    light: "#9fb8ff",
    dark: "#182357",
    orbitR: 448,
    sizeR: 11.5,
    periodDays: 60182,
    angle0: 2.9,
    au: 30.069,
    diameterKm: 49244,
    stats: [
      { label: "Diameter", value: "49,244 km" },
      { label: "Distance", value: "4,495M km · 30.1 AU" },
      { label: "Orbital period", value: "164.8 years" },
      { label: "Orbital speed", value: "5.4 km/s" },
      { label: "Moons", value: "16" },
      { label: "Top winds", value: "2,100 km/h" },
    ],
    blurb:
      "The most distant planet was found with mathematics before telescopes. Supersonic winds tear across its deep-blue clouds — the fastest in the Solar System.",
  },
];

export const BODIES: Body[] = [SUN, ...PLANETS];

export function bodyById(id: string | null): Body | null {
  return BODIES.find((b) => b.id === id) ?? null;
}

/** angular position (rad) at a given simulated time */
export function angleAt(body: Body, simDays: number): number {
  if (body.periodDays <= 0) return body.angle0;
  return body.angle0 + (simDays / body.periodDays) * Math.PI * 2;
}
