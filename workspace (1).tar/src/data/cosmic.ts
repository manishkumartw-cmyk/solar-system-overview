import type { Stat } from "./bodies";

export interface CosmicBody {
  id: string;
  name: string;
  index: string;
  type: string;
  color: string;
  light: string;
  dark: string;
  stats: Stat[];
  blurb: string;
}

export const COSMIC: Record<string, CosmicBody> = {
  "sun-far": {
    id: "sun-far",
    name: "Solar System",
    index: "ORION SPUR",
    type: "Planetary system · home",
    color: "#ffd98a",
    light: "#fff4d8",
    dark: "#a3701f",
    stats: [
      { label: "Star", value: "Sol · G2V" },
      { label: "Distance to core", value: "26,000 ly" },
      { label: "Galactic year", value: "~230 M yrs" },
      { label: "Speed around core", value: "230 km/s" },
      { label: "Members", value: "8 planets · 5 dwarfs" },
      { label: "Age", value: "4.6 bn yrs" },
    ],
    blurb:
      "Riding the Orion Spur between two major arms, our whole system circles the galactic core once every ~230 million years — last time we were here, the first dinosaurs were still 30 million years away.",
  },
  hubble: {
    id: "hubble",
    name: "Hubble",
    index: "HST · 1990",
    type: "Space telescope · LEO",
    color: "#8fd3ff",
    light: "#e6f7ff",
    dark: "#2b5d8a",
    stats: [
      { label: "Altitude", value: "~535 km" },
      { label: "Speed", value: "27,300 km/h" },
      { label: "Orbit period", value: "~95 min" },
      { label: "Primary mirror", value: "2.4 m" },
      { label: "Length · mass", value: "13.2 m · 11.1 t" },
      { label: "Observations", value: "1.5 M+" },
    ],
    blurb:
      "Flying above the blurring atmosphere since 1990, Hubble stares ~13.4 billion years into the past. Its Ultra Deep Field packed 10,000 galaxies into a patch of sky smaller than a grain of sand held at arm's length.",
  },
  milkyway: {
    id: "milkyway",
    name: "Milky Way",
    index: "GAL · 01",
    type: "Barred spiral · SBbc",
    color: "#ffe2a8",
    light: "#fff7e0",
    dark: "#8a6420",
    stats: [
      { label: "Diameter", value: "100–180 k ly" },
      { label: "Stars", value: "100–400 bn" },
      { label: "Mass", value: "~1.5 tn M☉" },
      { label: "Core", value: "Sgr A* · 4.15 M M☉" },
      { label: "Sun's orbit", value: "230 M yrs" },
      { label: "Age", value: "13.6 bn yrs" },
    ],
    blurb:
      "A barred spiral with at least two major arms. At its heart sits Sagittarius A*, a supermassive black hole 4.15 million times the Sun's mass — imaged in 2022 by the Event Horizon Telescope.",
  },
  andromeda: {
    id: "andromeda",
    name: "Andromeda",
    index: "M31 · NGC 224",
    type: "Spiral galaxy · SA(s)b",
    color: "#e8c48f",
    light: "#fff1d9",
    dark: "#7a5a2e",
    stats: [
      { label: "Diameter", value: "~220,000 ly" },
      { label: "Distance", value: "2.537 M ly" },
      { label: "Stars", value: "~1 trillion" },
      { label: "Approach speed", value: "110 km/s" },
      { label: "Merger with MW", value: "~4.5 bn yrs" },
      { label: "Naked-eye mag", value: "3.4" },
    ],
    blurb:
      "The most distant object visible to the naked eye and the Local Group's largest galaxy. It is falling toward us at 110 km/s; in ~4.5 billion years the two will merge into 'Milkomeda'.",
  },
  triangulum: {
    id: "triangulum",
    name: "Triangulum",
    index: "M33 · NGC 598",
    type: "Spiral galaxy · SA(s)cd",
    color: "#9fb9ff",
    light: "#e3ecff",
    dark: "#3c5188",
    stats: [
      { label: "Diameter", value: "~60,000 ly" },
      { label: "Distance", value: "2.73 M ly" },
      { label: "Stars", value: "~40 bn" },
      { label: "Rank in group", value: "3rd largest" },
      { label: "Notable", value: "NGC 604 nebula" },
      { label: "Naked-eye mag", value: "5.7" },
    ],
    blurb:
      "The third-largest member of the Local Group, possibly a satellite of Andromeda. Its face-on tilt makes it a favourite target — it hosts NGC 604, a star-forming region 40× the size of Orion's.",
  },
  lmc: {
    id: "lmc",
    name: "Large Magellanic Cloud",
    index: "LMC · ESO 56-115",
    type: "Magellanic spiral · dwarf",
    color: "#a8e0d8",
    light: "#e8fff9",
    dark: "#356a62",
    stats: [
      { label: "Diameter", value: "~14,000 ly" },
      { label: "Distance", value: "163,000 ly" },
      { label: "Stars", value: "~30 bn" },
      { label: "Mass", value: "~10 bn M☉" },
      { label: "Famous for", value: "SN 1987A" },
      { label: "Visible from", value: "Southern sky" },
    ],
    blurb:
      "A satellite of the Milky Way, distorted into a single off-centre bar by tidal gravity. In 1987 it lit up with SN 1987A — the closest supernova observed since the invention of the telescope.",
  },
  smc: {
    id: "smc",
    name: "Small Magellanic Cloud",
    index: "SMC · NGC 292",
    type: "Dwarf irregular",
    color: "#9ad0e8",
    light: "#e6f9ff",
    dark: "#2e5f74",
    stats: [
      { label: "Diameter", value: "~7,000 ly" },
      { label: "Distance", value: "200,000 ly" },
      { label: "Stars", value: "few hundred M" },
      { label: "Companion", value: "The LMC" },
      { label: "Tied by", value: "Magellanic Stream" },
      { label: "Visible from", value: "Southern sky" },
    ],
    blurb:
      "Once perhaps a barred spiral, the SMC is being slowly torn apart by the Milky Way's gravity, trailing a 600,000-light-year ribbon of hydrogen gas called the Magellanic Stream.",
  },
};

/* ------------------------------------------------------------------ */
/*  procedural spiral-galaxy art                                       */
/* ------------------------------------------------------------------ */

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function spiralPoint(
  t: number,
  rMax: number,
  turns: number,
  phase: number,
  cx = 0,
  cy = 0
): { x: number; y: number } {
  const th = phase + t * turns * Math.PI * 2;
  const r = rMax * Math.pow(Math.max(t, 0.0001), 0.8);
  return { x: cx + r * Math.cos(th), y: cy - r * Math.sin(th) };
}

export function spiralPath(
  rMax: number,
  turns: number,
  phase: number,
  cx = 0,
  cy = 0,
  steps = 150
): string {
  let d = "";
  for (let i = 0; i <= steps; i++) {
    const t = 0.045 + 0.955 * (i / steps);
    const p = spiralPoint(t, rMax, turns, phase, cx, cy);
    d += `${i === 0 ? "M" : "L"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
  }
  return d;
}

export interface ArmStar {
  x: number;
  y: number;
  r: number;
  o: number;
  warm: boolean;
}

export function armStars(
  seed: number,
  arms: number,
  rMax: number,
  turns: number,
  phase: number,
  count: number,
  spread: number,
  cx = 0,
  cy = 0
): ArmStar[] {
  const rnd = mulberry32(seed);
  const out: ArmStar[] = [];
  for (let i = 0; i < count; i++) {
    const t = 0.06 + 0.94 * Math.pow(rnd(), 0.85);
    const armPhase = phase + (i % arms) * ((Math.PI * 2) / arms);
    const base = spiralPoint(t, rMax, turns, armPhase, cx, cy);
    const j = spread * (0.22 + 0.78 * t);
    out.push({
      x: base.x + (rnd() - 0.5) * 2 * j,
      y: base.y + (rnd() - 0.5) * 2 * j,
      r: 0.5 + rnd() * 1.7,
      o: 0.1 + rnd() * 0.55,
      warm: rnd() > 0.8,
    });
  }
  return out;
}
